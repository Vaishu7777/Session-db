export const C = {
  bg      : '#06000d',
  surface : '#0d0018',
  surface2: '#130020',
  surface3: '#1a002b',
  border  : '#2a0040',
  border2 : '#3d005c',
  pink    : '#f472b6',
  pink2   : '#fbcfe8',
  purple  : '#a855f7',
  lav     : '#a78bfa',
  mint    : '#34d399',
  amber   : '#fbbf24',
  rose    : '#f43f5e',
  cyan    : '#22d3ee',
  text    : '#faf5ff',
  text2   : '#c4b5d4',
  text3   : '#7c6b8a',
  text4   : '#4a3d55',
};

export const panel = {
  background  : C.surface,
  border      : `1px solid ${C.border}`,
  borderRadius: 14,
  padding     : '18px 20px',
  position    : 'relative',
  overflow    : 'hidden',
};

export const ttStyle = {
  backgroundColor: C.surface3,
  border         : `1px solid ${C.border2}`,
  borderRadius   : 8,
  color          : C.text2,
  fontSize       : 11,
};

export const monoFont = "'JetBrains Mono', monospace";

export function fmt(v, decimals = 2) {
  if (v == null || isNaN(v)) return '—';
  return Number(v).toFixed(decimals) + '%';
}

export function fmtNum(v) {
  if (v == null) return '—';
  return Number(v).toLocaleString();
}
