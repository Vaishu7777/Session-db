// ── Glassmorphism Dark Theme ──────────────────────────────────────
export const C = {
  // Backgrounds
  bg       : '#07091a',
  bg2      : '#0b0d24',
  glass    : 'rgba(255,255,255,0.04)',
  glassMd  : 'rgba(255,255,255,0.07)',
  glassHi  : 'rgba(255,255,255,0.10)',
  // Borders
  border   : 'rgba(255,255,255,0.08)',
  border2  : 'rgba(255,255,255,0.14)',
  // Accent
  blue     : '#3b82f6',
  blue2    : '#60a5fa',
  cyan     : '#22d3ee',
  green    : '#10b981',
  green2   : '#34d399',
  purple   : '#8b5cf6',
  purple2  : '#a78bfa',
  pink     : '#f472b6',
  pink2    : '#fbcfe8',
  amber    : '#f59e0b',
  amber2   : '#fbbf24',
  rose     : '#f43f5e',
  // Text
  text     : '#f1f5f9',
  text2    : '#94a3b8',
  text3    : '#64748b',
  text4    : '#334155',
  // Mono
  mono     : "'JetBrains Mono', monospace",
};

export const glass = (alpha = 0.06) => ({
  background    : `rgba(255,255,255,${alpha})`,
  backdropFilter: 'blur(20px)',
  WebkitBackdropFilter: 'blur(20px)',
  border        : `1px solid rgba(255,255,255,0.1)`,
  borderRadius  : 14,
});

export const glassCard = {
  ...glass(0.05),
  borderRadius  : 16,
  padding       : '18px 20px',
  position      : 'relative',
  overflow      : 'hidden',
};

export const ttStyle = {
  backgroundColor: 'rgba(7,9,26,0.95)',
  border         : '1px solid rgba(255,255,255,0.15)',
  borderRadius   : 10,
  color          : C.text2,
  fontSize       : 11,
  backdropFilter : 'blur(12px)',
};

export function fmt(v, d = 2) {
  if (v == null || isNaN(v)) return '—';
  return Number(v).toFixed(d) + '%';
}
export function fmtNum(v) {
  if (v == null) return '—';
  return Number(v).toLocaleString();
}
