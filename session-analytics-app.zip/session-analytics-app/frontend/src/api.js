import axios from 'axios';
const api = axios.create({ baseURL: '/api' });

export async function uploadFiles(files, onProgress) {
  const form = new FormData();
  Array.from(files).forEach(f => form.append('files', f));
  const res = await api.post('/upload', form, {
    headers: { 'Content-Type': 'multipart/form-data' },
    onUploadProgress: e => onProgress && onProgress(Math.round((e.loaded / e.total) * 100)),
  });
  return res.data;
}

function clean(p) {
  const out = {};
  for (const [k, v] of Object.entries(p || {})) {
    if (v === null || v === undefined || v === '') continue;
    if (Array.isArray(v)) { if (v.length) out[k] = v.join(','); } else out[k] = v;
  }
  return out;
}

export const fetchSummary  = async p => (await api.get('/kpis/summary',  { params: clean(p) })).data;
export const fetchKPI6     = async p => (await api.get('/kpis/kpi6',     { params: clean(p) })).data;
export const fetchTrend    = async p => (await api.get('/kpis/trend',    { params: clean(p) })).data;
export const fetchFallback = async p => (await api.get('/kpis/fallback', { params: clean(p) })).data;
export const fetchFilters  = async b => (await api.get('/kpis/filters',  { params: { batch: b } })).data;
export const fetchBatches  = async () => (await api.get('/kpis/batches')).data;
export const deleteBatch   = async id => api.delete(`/upload/${id}`);
export function exportUrl(p) {
  return `/api/export/excel?${new URLSearchParams(clean(p)).toString()}`;
}
