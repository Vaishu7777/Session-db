import axios from 'axios';

const api = axios.create({ baseURL: '/api' });

export async function uploadFiles(files, onProgress) {
  const form = new FormData();
  Array.from(files).forEach(f => form.append('files', f));
  const res = await api.post('/upload', form, {
    headers: { 'Content-Type': 'multipart/form-data' },
    onUploadProgress: e => onProgress && onProgress(Math.round((e.loaded/e.total)*100)),
  });
  return res.data;
}

export async function fetchSummary(params)  { return (await api.get('/kpis/summary',  { params: clean(params) })).data; }
export async function fetchTrend(params)    { return (await api.get('/kpis/trend',    { params: clean(params) })).data; }
export async function fetchFallback(params) { return (await api.get('/kpis/fallback', { params: clean(params) })).data; }
export async function fetchFilters(batch)   { return (await api.get('/kpis/filters',  { params: { batch } })).data; }
export async function fetchBatches()        { return (await api.get('/kpis/batches')).data; }
export async function fetchHsctDist(params) { return (await api.get('/kpis/hsct-dist',{ params: clean(params) })).data; }
export async function deleteBatch(id)       { await api.delete(`/upload/${id}`); }

export function exportUrl(params) {
  return `/api/export/excel?${new URLSearchParams(clean(params)).toString()}`;
}

function clean(p) {
  const o = {};
  for (const [k,v] of Object.entries(p||{})) {
    if (v===null||v===undefined||v==='') continue;
    if (Array.isArray(v)) { if (v.length) o[k]=v.join(','); }
    else o[k]=v;
  }
  return o;
}
