import { C, monoFont, fmt, fmtNum } from '../styles/theme';

export default function KPITable({ trend, hsctEnd, loginThr }) {
  if (!trend || !trend.length) return (
    <div style={{ padding: 40, textAlign: 'center', color: C.text3, fontSize: 13 }}>No trend data available</div>
  );

  const headers = [
    { label: 'Date',                   key: 'date',          color: C.text,  isNum: false },
    { label: 'Total Sessions',         key: 'total',         color: C.pink,  isNum: true  },
    { label: 'Plant Sessions',         key: 'plant',         color: C.mint,  isNum: true  },
    { label: 'Non-Plant Sessions',     key: 'nonPlant',      color: C.amber, isNum: true  },
    { label: 'Plant Attachment Rate',  key: 'plantRate',     color: C.rose,  isNum: false, isPct: true },
    { label: `% HSCT ≤ ${hsctEnd}s`,   key: 'hsctRate',      color: C.pink,  isNum: false, isPct: true },
    { label: `% Plant HSCT ≤ ${hsctEnd}s`, key: 'plantHsctRate', color: C.mint,  isNum: false, isPct: true },
    { label: `% NP MQTT HSCT ≤ ${hsctEnd}s`, key: 'npHsctRate', color: C.amber, isNum: false, isPct: true },
    { label: `% Login ≤ ${loginThr}s`, key: 'loginRate',     color: C.lav,   isNum: false, isPct: true },
  ];

  return (
    <div style={{ overflowX: 'auto' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
        <thead>
          <tr style={{ borderBottom: `1px solid ${C.border2}` }}>
            {headers.map(h => (
              <th key={h.key} style={{ padding: '10px 14px', textAlign: h.isNum || h.isPct ? 'right' : 'left', fontSize: 9, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.6px', color: h.color, fontFamily: monoFont, whiteSpace: 'nowrap', background: C.surface }}>
                {h.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {trend.map((row, i) => (
            <tr key={row.date} style={{ background: i % 2 === 0 ? 'transparent' : 'rgba(255,255,255,.012)', borderBottom: `1px solid ${C.border}55` }}>
              {headers.map(h => (
                <td key={h.key} style={{ padding: '9px 14px', textAlign: h.isNum || h.isPct ? 'right' : 'left', fontFamily: monoFont, fontWeight: h.isPct || h.isNum ? 600 : 500, color: h.isPct || h.isNum ? h.color : C.text, fontSize: 11, whiteSpace: 'nowrap' }}>
                  {h.isPct ? fmt(row[h.key]) : h.isNum ? fmtNum(row[h.key]) : row[h.key]}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
        {/* Totals row */}
        <tfoot>
          <tr style={{ borderTop: `2px solid ${C.border2}`, background: C.surface2 }}>
            <td style={{ padding: '10px 14px', fontFamily: monoFont, fontWeight: 700, color: C.pink, fontSize: 11 }}>TOTAL / AVG</td>
            <td style={{ padding: '10px 14px', textAlign: 'right', fontFamily: monoFont, fontWeight: 700, color: C.pink, fontSize: 11 }}>{fmtNum(trend.reduce((s, r) => s + r.total, 0))}</td>
            <td style={{ padding: '10px 14px', textAlign: 'right', fontFamily: monoFont, fontWeight: 700, color: C.mint, fontSize: 11 }}>{fmtNum(trend.reduce((s, r) => s + r.plant, 0))}</td>
            <td style={{ padding: '10px 14px', textAlign: 'right', fontFamily: monoFont, fontWeight: 700, color: C.amber, fontSize: 11 }}>{fmtNum(trend.reduce((s, r) => s + r.nonPlant, 0))}</td>
            {['plantRate','hsctRate','plantHsctRate','npHsctRate','loginRate'].map((k, i) => {
              const colors = [C.rose, C.pink, C.mint, C.amber, C.lav];
              const avg = trend.reduce((s, r) => s + (r[k] || 0), 0) / trend.length;
              return <td key={k} style={{ padding: '10px 14px', textAlign: 'right', fontFamily: monoFont, fontWeight: 700, color: colors[i], fontSize: 11 }}>{fmt(avg)}</td>;
            })}
          </tr>
        </tfoot>
      </table>
    </div>
  );
}
