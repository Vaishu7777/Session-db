import { C, fmtNum, fmt } from '../styles/theme';

export default function KPITable({ trend, hsctEnd, loginThr, hsctStart }) {
  if (!trend?.length) return <div style={{ padding:32, textAlign:'center', color:C.text3 }}>No data</div>;

  const cols = [
    { label:'Date',                         key:'date',          color:C.text,    num:false },
    { label:'Total Sessions',               key:'total',         color:C.blue2,   num:true  },
    { label:'Plant',                        key:'plant',         color:C.green2,  num:true  },
    { label:'Non-Plant',                    key:'nonPlant',      color:C.amber2,  num:true  },
    { label:'Plant Rate',                   key:'plantRate',     color:C.green2,  pct:true  },
    { label:`HSCT ≤${hsctEnd}s %`,          key:'hsctRate',      color:C.blue2,   pct:true  },
    { label:`Plant HSCT %`,                 key:'plantHsctRate', color:C.green2,  pct:true  },
    { label:`NP HSCT %`,                    key:'npHsctRate',    color:C.amber2,  pct:true  },
    { label:`Login ≤${loginThr}s %`,        key:'loginRate',     color:C.purple2, pct:true  },
  ];

  const totals = {
    total    : trend.reduce((s,r) => s+r.total,    0),
    plant    : trend.reduce((s,r) => s+r.plant,    0),
    nonPlant : trend.reduce((s,r) => s+r.nonPlant, 0),
    plantRate    : trend.reduce((s,r) => s+r.plantRate,    0) / trend.length,
    hsctRate     : trend.reduce((s,r) => s+r.hsctRate,     0) / trend.length,
    plantHsctRate: trend.reduce((s,r) => s+r.plantHsctRate,0) / trend.length,
    npHsctRate   : trend.reduce((s,r) => s+r.npHsctRate,   0) / trend.length,
    loginRate    : trend.reduce((s,r) => s+r.loginRate,     0) / trend.length,
  };

  return (
    <div style={{ overflowX:'auto' }}>
      <table style={{ width:'100%', borderCollapse:'collapse', fontSize:12 }}>
        <thead>
          <tr style={{ borderBottom:`1px solid rgba(255,255,255,0.1)` }}>
            {cols.map(c => (
              <th key={c.key} style={{ padding:'10px 14px', textAlign: c.num||c.pct?'right':'left', fontSize:9, fontWeight:700, textTransform:'uppercase', letterSpacing:'.6px', color:c.color, fontFamily:'monospace', whiteSpace:'nowrap', background:'rgba(255,255,255,0.03)' }}>{c.label}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {trend.map((row, i) => (
            <tr key={row.date} style={{ borderBottom:`1px solid rgba(255,255,255,0.05)`, background: i%2===0?'transparent':'rgba(255,255,255,0.02)', transition:'background .1s' }}
              onMouseEnter={e=>e.currentTarget.style.background='rgba(59,130,246,0.06)'}
              onMouseLeave={e=>e.currentTarget.style.background=i%2===0?'transparent':'rgba(255,255,255,0.02)'}
            >
              {cols.map(c => (
                <td key={c.key} style={{ padding:'9px 14px', textAlign: c.num||c.pct?'right':'left', fontFamily:'monospace', fontWeight:c.pct||c.num?600:500, color:c.color, fontSize:11, whiteSpace:'nowrap' }}>
                  {c.pct ? fmt(row[c.key]) : c.num ? fmtNum(row[c.key]) : row[c.key]}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
        <tfoot>
          <tr style={{ borderTop:`2px solid rgba(255,255,255,0.12)`, background:'rgba(255,255,255,0.04)' }}>
            <td style={{ padding:'10px 14px', fontFamily:'monospace', fontWeight:700, color:C.text, fontSize:11 }}>TOTAL / AVG</td>
            <td style={{ padding:'10px 14px', textAlign:'right', fontFamily:'monospace', fontWeight:700, color:C.blue2,   fontSize:12 }}>{fmtNum(totals.total)}</td>
            <td style={{ padding:'10px 14px', textAlign:'right', fontFamily:'monospace', fontWeight:700, color:C.green2,  fontSize:12 }}>{fmtNum(totals.plant)}</td>
            <td style={{ padding:'10px 14px', textAlign:'right', fontFamily:'monospace', fontWeight:700, color:C.amber2,  fontSize:12 }}>{fmtNum(totals.nonPlant)}</td>
            {['plantRate','hsctRate','plantHsctRate','npHsctRate','loginRate'].map((k,i)=>{
              const cols2=[C.green2,C.blue2,C.green2,C.amber2,C.purple2];
              return <td key={k} style={{ padding:'10px 14px', textAlign:'right', fontFamily:'monospace', fontWeight:700, color:cols2[i], fontSize:12 }}>{fmt(totals[k])}</td>;
            })}
          </tr>
        </tfoot>
      </table>
    </div>
  );
}
