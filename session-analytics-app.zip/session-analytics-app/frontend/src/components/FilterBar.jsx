// FilterBar exports BUILD_VERSIONS and LCC_REVISIONS for Dashboard.jsx
export const BUILD_VERSIONS = [
  '4.60.0106','4.60.0108','4.60.0109','4.60.0111','4.60.0115',
];

export const LCC_REVISIONS = [
  '03.00.0465','03.00.0492','03.00.0493',
  '03.92.0725','03.92.0729',
  '03.95.0350','03.95.0700',
  '04.27.0038','04.27.0045','04.27.0054',
  '04.31.0066','04.31.0545','04.31.0550',
  '04.33.0217','04.35.0259',
  '04.38.0161','04.38.1632',
  '04.40.0169','04.40.0183','04.40.0190','04.40.0364',
  '04.60.0257',
];

// FilterBar is now embedded in Dashboard.jsx sidebar — this file just exports constants
export default function FilterBar() { return null; }
