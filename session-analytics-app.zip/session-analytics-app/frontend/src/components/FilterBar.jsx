import { useState } from 'react';
import { C } from '../styles/theme';

// ── Preset values from spec ───────────────────────────────────────
export const BUILD_VERSIONS = [
  '4.60.0106','4.60.0108','4.60.0109','4.60.0111','4.60.0115',
];

export const LCC_REVISIONS = [
  '03.00.0465','03.00.0492','03.00.0493',
  '03.92.0725','03.92.0729',
  '03.95.0350','03.95.0700',
  '04.27.0038','04.27.0045','04.27.0054',
  '04.31.0066','04.31.0545','04.31.0550',
  '04.33.0217',
  '04.35.0259',
  '04.38.0161','04.38.1632',
  '04.40.0169','04.40.0183','04.40.0190','04.40.0364',
  '04.60.0257',
];

export default function FilterBar({ filters, dynamicOptions = {}, onChange, onApply, onExport, onNewUpload, meta }) {
  const [bvOpen,  setBvOpen]  = useState(false);
  const [lccOpen, setLccOpen] = useState(false);

  // Merge preset + dynamic (from uploaded data)
  const bvOptions  = [...new Set([...BUILD_VERSIONS,  ...(dynamicOptions.buildVersions || [])])].sort();
  const lccOptions = [...new Set([...LCC_REVISIONS,   ...(dynamicOptions.lccRevisions  || [])])].sort();

  function toggleBv(v) {
    const cur = filters.buildVersions || [];
    onChange('buildVersions', cur.includes(v) ? cur.filter(x => x !== v) : [...cur, v]);
  }
  function toggleLcc(v) {
    const cur = filters.lccRevisions || [];
    onChange('lccRevisions', cur.includes(v) ? cur.filter(x => x !== v) : [...cur, v]);
  }

  const numInput = (key, label, min, max, step = 0.5, unit = 'sec') => (
    <div style={{ display:'flex', alignItems:'center', gap:5, background:C.surface2, border:`1px solid ${C.border2}`, borderRadius:7, padding:'5px 10px' }}>
      <span style={{ fontSize:9, color:C.text3, textTransform:'uppercase', letterSpacing:'.5px', fontWeight:600, whiteSpace:'nowrap' }}>{label}</span>
      <input
        type="number" value={filters[key]} min={min} max={max} step={step}
        onChange={e => onChange(key, Number(e.target.value))}
        style={{ width:42, background:'transparent', border:'none', outline:'none', color:C.pink, fontFamily:'monospace', fontSize:12, fontWeight:700, textAlign:'center' }}
      />
      {unit && <span style={{ fontSize:9, color:C.text3 }}>{unit}</span>}
    </div>
  );

  const multiBtn = (label, open, setOpen, selected, options, toggle, color) => (
    <div style={{ position:'relative' }}>
      <button
        onClick={() => { setOpen(!open); }}
        style={{ display:'flex', alignItems:'center', gap:6, background:C.surface2, border:`1px solid ${open ? color : C.border2}`, borderRadius:7, padding:'5px 11px', cursor:'pointer', fontFamily:'inherit' }}
      >
        <span style={{ fontSize:9, color:C.text3, textTransform:'uppercase', letterSpacing:'.5px', fontWeight:600 }}>{label}</span>
        <span style={{ fontSize:10, color:color, fontFamily:'monospace', fontWeight:700 }}>
          {selected.length === 0 ? 'All' : selected.length === 1 ? selected[0] : `${selected.length} selected`}
        </span>
        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2.5">
          <polyline points={open ? '18 15 12 9 6 15' : '6 9 12 15 18 9'} />
        </svg>
      </button>
      {open && (
        <div style={{ position:'absolute', top:'calc(100% + 6px)', left:0, zIndex:500, background:C.surface3, border:`1px solid ${C.border2}`, borderRadius:10, minWidth:200, maxHeight:280, overflowY:'auto', boxShadow:`0 8px 32px rgba(0,0,0,.6)` }}>
          <div style={{ padding:'8px 10px', borderBottom:`1px solid ${C.border}`, display:'flex', justifyContent:'space-between', alignItems:'center' }}>
            <span style={{ fontSize:10, color:C.text3, fontWeight:600 }}>Select {label}</span>
            <div style={{ display:'flex', gap:8 }}>
              <button onClick={() => options.forEach(v => { if (!selected.includes(v)) toggle(v); })} style={{ fontSize:9, color:C.mint, background:'none', border:'none', cursor:'pointer', fontWeight:600 }}>All</button>
              <button onClick={() => selected.forEach(v => toggle(v))} style={{ fontSize:9, color:C.rose, background:'none', border:'none', cursor:'pointer', fontWeight:600 }}>Clear</button>
            </div>
          </div>
          {options.map(v => (
            <div key={v} onClick={() => toggle(v)}
              style={{ display:'flex', alignItems:'center', gap:8, padding:'7px 12px', cursor:'pointer', background: selected.includes(v) ? `${color}14` : 'transparent', borderBottom:`1px solid ${C.border}33` }}
            >
              <div style={{ width:14, height:14, borderRadius:3, border:`1.5px solid ${selected.includes(v) ? color : C.border2}`, background: selected.includes(v) ? color : 'transparent', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0, transition:'all .15s' }}>
                {selected.includes(v) && <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="#06000d" strokeWidth="3.5"><polyline points="20 6 9 17 4 12"/></svg>}
              </div>
              <span style={{ fontSize:11, fontFamily:'monospace', color: selected.includes(v) ? color : C.text2 }}>{v}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  return (
    <>
      {/* Overlay to close dropdowns */}
      {(bvOpen || lccOpen) && (
        <div style={{ position:'fixed', inset:0, zIndex:400 }} onClick={() => { setBvOpen(false); setLccOpen(false); }} />
      )}

      <div style={{ background:'rgba(13,0,24,.9)', borderBottom:`1px solid ${C.border}`, padding:'10px 22px', display:'flex', alignItems:'center', justifyContent:'space-between', flexWrap:'wrap', gap:10, position:'sticky', top:56, zIndex:300, backdropFilter:'blur(16px)' }}>

        {/* Left: file info */}
        <div style={{ display:'flex', alignItems:'center', gap:8, flexWrap:'wrap' }}>
          <div style={{ display:'flex', alignItems:'center', gap:6, background:`${C.pink}10`, border:`1px solid ${C.pink}28`, borderRadius:7, padding:'4px 11px' }}>
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke={C.pink} strokeWidth="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
            <span style={{ fontFamily:'monospace', fontSize:11, color:C.pink2 }}>{meta?.fileCount || 0} file{meta?.fileCount !== 1 ? 's' : ''} · {(meta?.totalInserted||0).toLocaleString()} distinct sessions</span>
          </div>
          {meta && <span style={{ fontSize:10, color:C.text3 }}>{(meta.totalRaw||0).toLocaleString()} raw · {((meta.totalRaw||0)-(meta.totalInserted||0)).toLocaleString()} dupes removed</span>}
        </div>

        {/* Right: controls */}
        <div style={{ display:'flex', alignItems:'center', gap:8, flexWrap:'wrap' }}>
          {/* HSCT range */}
          <div style={{ display:'flex', alignItems:'center', gap:4, background:C.surface2, border:`1px solid ${C.border2}`, borderRadius:7, padding:'5px 10px' }}>
            <span style={{ fontSize:9, color:C.text3, textTransform:'uppercase', letterSpacing:'.5px', fontWeight:600 }}>HSCT</span>
            <input type="number" value={filters.hsctStart} min={0} max={60} step={0.5}
              onChange={e => onChange('hsctStart', Number(e.target.value))}
              style={{ width:36, background:'transparent', border:'none', outline:'none', color:C.cyan, fontFamily:'monospace', fontSize:12, fontWeight:700, textAlign:'center' }}
            />
            <span style={{ fontSize:10, color:C.text3 }}>–</span>
            <input type="number" value={filters.hsctEnd} min={0} max={120} step={0.5}
              onChange={e => onChange('hsctEnd', Number(e.target.value))}
              style={{ width:36, background:'transparent', border:'none', outline:'none', color:C.pink, fontFamily:'monospace', fontSize:12, fontWeight:700, textAlign:'center' }}
            />
            <span style={{ fontSize:9, color:C.text3 }}>sec</span>
          </div>

          {numInput('loginThr', 'Login ≤', 0, 60, 0.5, 'sec')}
          {numInput('lastDays', 'Last Days', 0, 365, 1, '')}

          {/* BuildVersion multi-select */}
          {multiBtn('Build Version', bvOpen, setBvOpen, filters.buildVersions || [], bvOptions, toggleBv, C.pink)}

          {/* LCC multi-select */}
          {multiBtn('LCC Revision', lccOpen, setLccOpen, filters.lccRevisions || [], lccOptions, toggleLcc, C.mint)}

          <button onClick={onApply} style={{ background:`linear-gradient(135deg,${C.pink},${C.purple})`, border:'none', borderRadius:7, padding:'7px 18px', color:C.bg, fontSize:11, fontWeight:700, cursor:'pointer' }}>
            Apply
          </button>

          <button onClick={onExport} style={{ display:'flex', alignItems:'center', gap:5, background:`${C.mint}18`, border:`1px solid ${C.mint}33`, color:C.mint, borderRadius:7, padding:'7px 13px', fontSize:11, fontWeight:600, cursor:'pointer', fontFamily:'inherit' }}>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            Export Excel
          </button>

          <button onClick={onNewUpload} style={{ display:'flex', alignItems:'center', gap:5, background:C.surface2, border:`1px solid ${C.border2}`, color:C.text2, borderRadius:7, padding:'7px 12px', fontSize:11, cursor:'pointer', fontFamily:'inherit' }}>
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 102.13-9.36L1 10"/></svg>
            New Upload
          </button>
        </div>
      </div>
    </>
  );
}
