import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from 'recharts';
import { C, panel, ttStyle, fmt, fmtNum } from '../styles/theme';

const axTick = { fill: C.text3, fontSize: 10 };

function PanelWrap({ title, badge, children, style }) {
  return (
    <div style={{ ...panel, ...style }}>
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 2, background: `linear-gradient(90deg,${C.pink},${C.purple})`, borderRadius: '14px 14px 0 0' }} />
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14, marginTop: 4 }}>
        <span style={{ fontSize: 10, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.8px', color: C.text3 }}>{title}</span>
        {badge && <span style={{ fontSize: 9, fontFamily: 'monospace', background: C.surface2, border: `1px solid ${C.border2}`, borderRadius: 4, padding: '2px 7px', color: C.text3 }}>{badge}</span>}
      </div>
      {children}
    </div>
  );
}

// ── KPI Trend Line Chart ─────────────────────────────────────────
export function KPITrendChart({ data, hsctEnd, loginThr }) {
  if (!data?.length) return null;
  const formatted = data.map(r => ({ ...r, date: r.date?.slice(5) }));
  return (
    <PanelWrap title="KPI Trend Over Time" badge={`DISTINCT Count(SessionId) · per date`}>
      <ResponsiveContainer width="100%" height={240}>
        <LineChart data={formatted} margin={{ top: 4, right: 8, bottom: 0, left: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke={C.border} />
          <XAxis dataKey="date" tick={axTick} interval="preserveStartEnd" />
          <YAxis tick={axTick} tickFormatter={v => v + '%'} domain={[0, 100]} />
          <Tooltip contentStyle={ttStyle} formatter={v => fmt(v)} labelStyle={{ color: C.text2 }} />
          <Legend wrapperStyle={{ fontSize: 11, color: C.text3 }} />
          <Line type="monotone" dataKey="plantRate"     name="Plant Rate %"            stroke={C.mint}   dot={false} strokeWidth={2} />
          <Line type="monotone" dataKey="hsctRate"      name={`HSCT ≤${hsctEnd}s %`}   stroke={C.pink}   dot={false} strokeWidth={2} />
          <Line type="monotone" dataKey="plantHsctRate" name={`Plant HSCT ≤${hsctEnd}s %`} stroke={C.cyan} dot={false} strokeWidth={1.5} />
          <Line type="monotone" dataKey="npHsctRate"    name={`NP HSCT ≤${hsctEnd}s %`}   stroke={C.amber}  dot={false} strokeWidth={1.5} strokeDasharray="4 3" />
          <Line type="monotone" dataKey="loginRate"     name={`Login ≤${loginThr}s %`} stroke={C.lav}   dot={false} strokeWidth={2} />
        </LineChart>
      </ResponsiveContainer>
    </PanelWrap>
  );
}

// ── Sessions Volume Bar Chart ────────────────────────────────────
export function SessionsVolumeChart({ data }) {
  if (!data?.length) return null;
  const formatted = data.map(r => ({ ...r, date: r.date?.slice(5) }));
  return (
    <PanelWrap title="Total Sessions Trend" badge="Count(SessionId) by Date · KPI 18">
      <ResponsiveContainer width="100%" height={210}>
        <BarChart data={formatted} margin={{ top: 4, right: 8, bottom: 0, left: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke={C.border} />
          <XAxis dataKey="date" tick={axTick} interval="preserveStartEnd" />
          <YAxis tick={axTick} />
          <Tooltip contentStyle={ttStyle} formatter={v => fmtNum(v)} labelStyle={{ color: C.text2 }} />
          <Bar dataKey="total" name="Sessions" fill={C.pink + '55'} stroke={C.pink} strokeWidth={1} radius={[4, 4, 0, 0]} />
          <Bar dataKey="plant" name="Plant" fill={C.mint + '55'} stroke={C.mint} strokeWidth={1} radius={[4, 4, 0, 0]} />
          <Bar dataKey="nonPlant" name="Non-Plant" fill={C.amber + '55'} stroke={C.amber} strokeWidth={1} radius={[4, 4, 0, 0]} />
          <Legend wrapperStyle={{ fontSize: 11, color: C.text3 }} />
        </BarChart>
      </ResponsiveContainer>
    </PanelWrap>
  );
}

// ── Plant vs Non-Plant Donut ─────────────────────────────────────
export function PlantDonutChart({ plant, nonPlant, total }) {
  const data = [{ name: 'Plant', value: plant }, { name: 'Non-Plant', value: nonPlant }];
  const pct  = v => (v && total ? ((v / total) * 100).toFixed(1) + '%' : '—');
  return (
    <PanelWrap title="Session Distribution" badge="Plant vs Non-Plant">
      <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
        <ResponsiveContainer width={160} height={160}>
          <PieChart>
            <Pie data={data} cx="50%" cy="50%" innerRadius={52} outerRadius={76} dataKey="value" stroke="none">
              <Cell fill={C.mint + 'cc'} />
              <Cell fill={C.amber + 'cc'} />
            </Pie>
            <Tooltip contentStyle={ttStyle} formatter={v => fmtNum(v)} />
          </PieChart>
        </ResponsiveContainer>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {[['Plant', plant, C.mint], ['Non-Plant', nonPlant, C.amber], ['Total', total, C.pink]].map(([lbl, val, col]) => (
            <div key={lbl} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{ width: 8, height: 8, borderRadius: '50%', background: col, flexShrink: 0 }} />
              <span style={{ fontSize: 11, color: C.text2 }}>{lbl}</span>
              <span style={{ fontFamily: 'monospace', fontSize: 13, fontWeight: 700, color: col, marginLeft: 'auto', paddingLeft: 14 }}>{fmtNum(val)}</span>
            </div>
          ))}
          <div style={{ paddingTop: 8, borderTop: `1px solid ${C.border}` }}>
            <div style={{ fontSize: 10, color: C.text3 }}>Plant Rate</div>
            <div style={{ fontFamily: 'monospace', fontSize: 16, fontWeight: 700, color: C.rose }}>{pct(plant)}</div>
          </div>
        </div>
      </div>
    </PanelWrap>
  );
}

// ── Fallback Top 5 Horizontal Bar ───────────────────────────────
export function FallbackChart({ data }) {
  if (!data?.length) return (
    <PanelWrap title="Fallback Trend — Top 5" badge="KPI 17 · excl. nan">
      <div style={{ padding: 32, textAlign: 'center', color: C.text3, fontSize: 12 }}>No fallback cause data found</div>
    </PanelWrap>
  );
  const COLORS = [C.pink, C.purple, C.mint, C.amber, C.rose];
  const chartData = data.map((d, i) => ({ name: d.cause.length > 20 ? d.cause.slice(0, 20) + '…' : d.cause, count: d.total, fill: COLORS[i] }));

  return (
    <PanelWrap title="Fallback Trend — Top 5" badge="Count(DISTINCT SessionId) · excl. nan">
      <ResponsiveContainer width="100%" height={230}>
        <BarChart data={chartData} layout="vertical" margin={{ top: 4, right: 30, bottom: 0, left: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke={C.border} horizontal={false} />
          <XAxis type="number" tick={axTick} />
          <YAxis type="category" dataKey="name" tick={{ fill: C.text2, fontSize: 11 }} width={150} />
          <Tooltip contentStyle={ttStyle} formatter={v => [fmtNum(v), 'Sessions']} />
          <Bar dataKey="count" radius={[0, 4, 4, 0]}>
            {chartData.map((d, i) => <Cell key={i} fill={d.fill + '88'} stroke={d.fill} strokeWidth={1.5} />)}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </PanelWrap>
  );
}

// ── HSCT Rate Progress Bars ──────────────────────────────────────
export function RateBreakdownChart({ summary, hsctEnd, loginThr }) {
  const rows = [
    { label: 'Plant Attachment Rate',       value: summary.plantAttachRate,  color: C.rose,   grad: `linear-gradient(90deg,${C.rose},${C.pink})` },
    { label: `HSCT ≤ ${hsctEnd}s Rate`,     value: summary.hsctRate,         color: C.pink,   grad: `linear-gradient(90deg,${C.pink},${C.purple})` },
    { label: `Plant HSCT ≤ ${hsctEnd}s`,    value: summary.plantHsctRate,    color: C.mint,   grad: `linear-gradient(90deg,${C.mint},${C.cyan})` },
    { label: `NP MQTT HSCT ≤ ${hsctEnd}s`,  value: summary.nonPlantHsctRate, color: C.amber,  grad: `linear-gradient(90deg,${C.amber},#f97316)` },
    { label: `Login ≤ ${loginThr}s Rate`,    value: summary.loginRate,        color: C.lav,    grad: `linear-gradient(90deg,${C.lav},${C.purple})` },
  ];
  return (
    <PanelWrap title="Rate Breakdown" badge="All metrics vs denominator">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 13 }}>
        {rows.map(r => (
          <div key={r.label} style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
              <span style={{ fontSize: 11, color: C.text2 }}>{r.label}</span>
              <span style={{ fontFamily: 'monospace', fontSize: 12, fontWeight: 700, color: r.color }}>{fmt(r.value)}</span>
            </div>
            <div style={{ height: 6, background: C.surface2, borderRadius: 3, overflow: 'hidden' }}>
              <div style={{ height: '100%', width: Math.min(r.value || 0, 100) + '%', background: r.grad, borderRadius: 3, transition: 'width 1.3s' }} />
            </div>
          </div>
        ))}
      </div>
    </PanelWrap>
  );
}
