import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from 'recharts';
import { C, glassCard, ttStyle, fmt, fmtNum } from '../styles/theme';

const ax = { fill: C.text3, fontSize: 10 };

function Card({ title, badge, children, accent, style }) {
  const col = accent || C.blue;
  return (
    <div style={{ ...glassCard, ...style }}>
      <div style={{ position:'absolute', top:0, left:0, right:0, height:2, background:`linear-gradient(90deg,${col},${col}44)`, borderRadius:'16px 16px 0 0' }} />
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:14 }}>
        <span style={{ fontSize:10, fontWeight:700, textTransform:'uppercase', letterSpacing:'.8px', color:C.text3 }}>{title}</span>
        {badge && <span style={{ fontSize:9, fontFamily:'monospace', background:'rgba(255,255,255,0.06)', border:`1px solid rgba(255,255,255,0.1)`, borderRadius:5, padding:'2px 8px', color:C.text3 }}>{badge}</span>}
      </div>
      {children}
    </div>
  );
}

// ── Semicircle HSCT Health Gauge ──────────────────────────────────
export function HSCTHealthGauge({ summary }) {
  if (!summary) return null;
  const v = summary.hsctRate || 0;
  // Semicircle: from 180deg to 0deg = 0% to 100%
  const r = 72, cx = 100, cy = 90;
  const circ = Math.PI * r;
  const offset = circ - (v / 100) * circ;
  const color = v >= 80 ? C.green : v >= 60 ? C.amber : C.rose;

  const metrics = [
    { label:'HSCT Rate',       val:fmt(summary.hsctRate),      col:C.blue2  },
    { label:'Plant HSCT',      val:fmt(summary.plantHsctRate), col:C.green2 },
    { label:'NP HSCT',         val:fmt(summary.nonPlantHsctRate), col:C.amber2 },
    { label:'Login Success',   val:fmt(summary.loginRate),     col:C.purple2 },
  ];

  return (
    <Card title="HSCT Health" badge={`≤${summary.hsctEnd}s threshold`} accent={color}>
      <div style={{ display:'flex', flexDirection:'column', alignItems:'center' }}>
        <svg width="200" height="108" viewBox="0 0 200 108">
          {/* Track */}
          <path d={`M ${cx-r},${cy} A ${r},${r} 0 0,1 ${cx+r},${cy}`}
            fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="12" strokeLinecap="round" />
          {/* Value arc */}
          <path d={`M ${cx-r},${cy} A ${r},${r} 0 0,1 ${cx+r},${cy}`}
            fill="none" stroke={color} strokeWidth="12" strokeLinecap="round"
            strokeDasharray={`${circ}`} strokeDashoffset={`${offset}`}
            style={{ transition:'stroke-dashoffset 1.4s cubic-bezier(.22,1,.36,1)', filter:`drop-shadow(0 0 8px ${color})` }}
          />
          {/* Value text */}
          <text x={cx} y={cy-4} textAnchor="middle" fill={color} fontSize="26" fontFamily="JetBrains Mono,monospace" fontWeight="700">{fmt(v)}</text>
          <text x={cx} y={cy+14} textAnchor="middle" fill={C.text3} fontSize="10">HSCT Rate</text>
        </svg>

        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'8px 20px', width:'100%', marginTop:4 }}>
          {metrics.map(m => (
            <div key={m.label} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'5px 8px', background:'rgba(255,255,255,0.04)', borderRadius:7 }}>
              <span style={{ fontSize:10, color:C.text3 }}>{m.label}</span>
              <span style={{ fontFamily:'monospace', fontSize:12, fontWeight:700, color:m.col }}>{m.val}</span>
            </div>
          ))}
        </div>
      </div>
    </Card>
  );
}

// ── HSCT Distribution Bar Chart ───────────────────────────────────
export function HSCTDistributionChart({ data }) {
  if (!data?.length) return null;
  const colors = [C.green2, C.blue2, C.amber2, C.rose, C.purple2];
  return (
    <Card title="HSCT Distribution" badge="Session buckets by seconds" accent={C.blue}>
      <ResponsiveContainer width="100%" height={180}>
        <BarChart data={data} margin={{ top:4, right:8, bottom:0, left:0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
          <XAxis dataKey="bucket" tick={ax} />
          <YAxis tick={ax} />
          <Tooltip contentStyle={ttStyle} formatter={v => [fmtNum(v),'Sessions']} />
          <Bar dataKey="count" radius={[5,5,0,0]}>
            {data.map((_, i) => <Cell key={i} fill={colors[i % colors.length] + 'cc'} stroke={colors[i % colors.length]} strokeWidth={1} />)}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </Card>
  );
}

// ── Total Sessions Trend ──────────────────────────────────────────
export function SessionsVolumeChart({ data }) {
  if (!data?.length) return null;
  const d = data.map(r => ({ ...r, date: r.date?.slice(5) }));
  return (
    <Card title="Total Sessions Trend" badge="COUNT(DISTINCT SessionId) by Date" accent={C.blue}>
      <ResponsiveContainer width="100%" height={200}>
        <LineChart data={d} margin={{ top:4, right:8, bottom:0, left:0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
          <XAxis dataKey="date" tick={ax} interval="preserveStartEnd" />
          <YAxis tick={ax} />
          <Tooltip contentStyle={ttStyle} formatter={v => [fmtNum(v)]} />
          <Legend wrapperStyle={{ fontSize:11, color:C.text3 }} />
          <Line type="monotone" dataKey="plant"    name="Plant"     stroke={C.green2} dot={false} strokeWidth={2} />
          <Line type="monotone" dataKey="nonPlant" name="Non-Plant" stroke={C.blue2}  dot={false} strokeWidth={2} />
          <Line type="monotone" dataKey="total"    name="Total"     stroke={C.text2}  dot={false} strokeWidth={1.5} strokeDasharray="4 3" />
        </LineChart>
      </ResponsiveContainer>
    </Card>
  );
}

// ── KPI Rate Trend ────────────────────────────────────────────────
export function KPITrendChart({ data, hsctEnd, loginThr }) {
  if (!data?.length) return null;
  const d = data.map(r => ({ ...r, date: r.date?.slice(5) }));
  return (
    <Card title="KPI Rate Trend" badge="% over time" accent={C.purple}>
      <ResponsiveContainer width="100%" height={200}>
        <LineChart data={d} margin={{ top:4, right:8, bottom:0, left:0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
          <XAxis dataKey="date" tick={ax} interval="preserveStartEnd" />
          <YAxis tick={ax} tickFormatter={v => v+'%'} domain={[0,100]} />
          <Tooltip contentStyle={ttStyle} formatter={v => [fmt(v)]} />
          <Legend wrapperStyle={{ fontSize:11, color:C.text3 }} />
          <Line type="monotone" dataKey="plantRate"     name="Plant Rate %"         stroke={C.green2}  dot={false} strokeWidth={2} />
          <Line type="monotone" dataKey="hsctRate"      name={`HSCT ≤${hsctEnd}s %`} stroke={C.blue2}  dot={false} strokeWidth={2} />
          <Line type="monotone" dataKey="plantHsctRate" name="Plant HSCT %"         stroke={C.cyan}    dot={false} strokeWidth={1.5} />
          <Line type="monotone" dataKey="npHsctRate"    name="NP HSCT %"            stroke={C.amber2}  dot={false} strokeWidth={1.5} strokeDasharray="4 3" />
          <Line type="monotone" dataKey="loginRate"     name={`Login ≤${loginThr}s %`} stroke={C.purple2} dot={false} strokeWidth={2} />
        </LineChart>
      </ResponsiveContainer>
    </Card>
  );
}

// ── Plant vs Non-Plant Donut ──────────────────────────────────────
export function PlantDonutChart({ plant, nonPlant, total }) {
  const data = [{ name:'Plant', value:plant }, { name:'Non-Plant', value:nonPlant }];
  return (
    <Card title="Session Distribution" badge="Plant vs Non-Plant" accent={C.green}>
      <div style={{ display:'flex', alignItems:'center', gap:16 }}>
        <div style={{ position:'relative', flexShrink:0 }}>
          <PieChart width={130} height={130}>
            <Pie data={data} cx={65} cy={65} innerRadius={42} outerRadius={62} dataKey="value" stroke="none">
              <Cell fill={C.green2+'bb'} />
              <Cell fill={C.blue2+'bb'} />
            </Pie>
          </PieChart>
          <div style={{ position:'absolute', inset:0, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center' }}>
            <div style={{ fontFamily:'monospace', fontSize:14, fontWeight:700, color:C.text }}>{fmtNum(total)}</div>
            <div style={{ fontSize:9, color:C.text3 }}>Total</div>
          </div>
        </div>
        <div style={{ flex:1, display:'flex', flexDirection:'column', gap:10 }}>
          {[['Plant', plant, C.green2], ['Non-Plant', nonPlant, C.blue2]].map(([l,v,c]) => (
            <div key={l}>
              <div style={{ display:'flex', justifyContent:'space-between', marginBottom:4 }}>
                <span style={{ fontSize:11, color:C.text2 }}>{l}</span>
                <span style={{ fontFamily:'monospace', fontSize:12, fontWeight:700, color:c }}>{fmtNum(v)} <span style={{ color:C.text3, fontWeight:400 }}>({total?((v/total)*100).toFixed(1):'0'}%)</span></span>
              </div>
              <div style={{ height:5, background:'rgba(255,255,255,0.07)', borderRadius:3 }}>
                <div style={{ height:'100%', width:(total?Math.min((v/total)*100,100):0)+'%', background:c, borderRadius:3, transition:'width 1.3s' }} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </Card>
  );
}

// ── Fallback Trend Top 5 ──────────────────────────────────────────
export function FallbackChart({ data }) {
  const COLORS = [C.rose, C.amber2, C.purple2, C.cyan, C.green2];
  if (!data?.length) return (
    <Card title="Fallback Trend — Top 5" badge="excl. nan" accent={C.rose}>
      <div style={{ height:160, display:'flex', alignItems:'center', justifyContent:'center', color:C.text3, fontSize:12 }}>No fallback data</div>
    </Card>
  );
  return (
    <Card title="Fallback Trend — Top 5" badge="COUNT(DISTINCT) · excl. nan" accent={C.rose}>
      <ResponsiveContainer width="100%" height={180}>
        <BarChart data={data} layout="vertical" margin={{ top:4, right:30, bottom:0, left:0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" horizontal={false} />
          <XAxis type="number" tick={ax} />
          <YAxis type="category" dataKey="cause" tick={{ fill:C.text2, fontSize:10 }} width={130} />
          <Tooltip contentStyle={ttStyle} formatter={v => [fmtNum(v),'Sessions']} />
          <Bar dataKey="total" radius={[0,5,5,0]}>
            {data.map((_, i) => <Cell key={i} fill={COLORS[i]+'88'} stroke={COLORS[i]} strokeWidth={1.5} />)}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
      {/* Legend */}
      <div style={{ display:'flex', flexDirection:'column', gap:5, marginTop:10 }}>
        {data.map((d,i) => (
          <div key={i} style={{ display:'flex', alignItems:'center', justifyContent:'space-between', fontSize:10 }}>
            <div style={{ display:'flex', alignItems:'center', gap:6 }}>
              <div style={{ width:8, height:8, borderRadius:'50%', background:COLORS[i], flexShrink:0 }} />
              <span style={{ color:C.text2 }}>{d.cause}</span>
            </div>
            <span style={{ fontFamily:'monospace', color:COLORS[i], fontWeight:700 }}>{fmtNum(d.total)}</span>
          </div>
        ))}
      </div>
    </Card>
  );
}

// ── Session Heatmap ───────────────────────────────────────────────
export function SessionHeatmap({ trend }) {
  if (!trend?.length) return null;
  const vals = trend.map(r => r.total);
  const mx = Math.max(...vals, 1);
  return (
    <Card title="Session Volume Heatmap" badge="by date" accent={C.cyan}>
      <div style={{ display:'flex', flexWrap:'wrap', gap:4 }}>
        {trend.map((r, i) => {
          const a = 0.08 + (r.total / mx) * 0.88;
          return (
            <div key={i} title={`${r.date}: ${fmtNum(r.total)} sessions`}
              style={{ width:22, height:22, borderRadius:4, background:`rgba(59,130,246,${a.toFixed(2)})`, cursor:'default', position:'relative', transition:'transform .1s' }}
              onMouseEnter={e => e.currentTarget.style.transform='scale(1.3)'}
              onMouseLeave={e => e.currentTarget.style.transform='scale(1)'}
            />
          );
        })}
      </div>
      <div style={{ display:'flex', alignItems:'center', gap:8, marginTop:10 }}>
        <span style={{ fontSize:9, color:C.text3 }}>Low</span>
        <div style={{ flex:1, height:5, background:`linear-gradient(90deg,${C.blue}22,${C.blue})`, borderRadius:3 }} />
        <span style={{ fontSize:9, color:C.text3 }}>High</span>
      </div>
    </Card>
  );
}
