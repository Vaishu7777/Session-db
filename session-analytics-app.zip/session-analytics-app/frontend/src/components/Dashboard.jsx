import { useState, useEffect, useCallback } from 'react';
import { C, glassCard, glass, fmt, fmtNum } from '../styles/theme';
import KPICard from './KPICard';
import KPITable from './KPITable';
import {
  HSCTHealthGauge, HSCTDistributionChart, SessionsVolumeChart,
  KPITrendChart, PlantDonutChart, FallbackChart, SessionHeatmap
} from './Charts';
import { fetchSummary, fetchTrend, fetchFallback, fetchHsctDist, exportUrl } from '../api';
import { BUILD_VERSIONS, LCC_REVISIONS } from './FilterBar';

const TABS = ['Overview', 'Trends', 'Daily Table', 'Fallback'];

export default function Dashboard({ uploadResult, onNewUpload }) {
  const [tab, setTab]           = useState('Overview');
  const [summary, setSummary]   = useState(null);
  const [trend, setTrend]       = useState([]);
  const [fallback, setFallback] = useState([]);
  const [hsctDist, setHsctDist] = useState([]);
  const [dynOpts, setDynOpts]   = useState(uploadResult?.filterOptions || {});
  const [loading, setLoading]   = useState(false);
  const [loadMsg, setLoadMsg]   = useState('');
  const [sidebarOpen, setSidebar] = useState(true);
  const [filters, setFilters]   = useState({
    batch        : uploadResult?.batchId || null,
    hsctStart    : 0,
    hsctEnd      : 5,
    loginThr     : 1,
    lastDays     : 0,      // 0 = ALL dates (no date filter)
    buildVersions: [],
    lccRevisions : [],
    fromDate     : '',
    toDate       : '',
  });

  // ── STEP 2: Called automatically after upload stores data in DB ──
  const loadAll = useCallback(async (f) => {
    setLoading(true);
    setLoadMsg('Querying database…');
    try {
      console.log('🔍 Calling KPI APIs with batch:', f.batch);
      setLoadMsg('Fetching KPI summary from SQLite…');
      const [s, t, fb, hd] = await Promise.all([
        fetchSummary(f),
        fetchTrend(f),
        fetchFallback(f),
        fetchHsctDist(f),
      ]);
      console.log('✅ KPIs received:', s);
      setSummary(s);
      setTrend(t);
      setFallback(fb);
      setHsctDist(hd);
      setLoadMsg('');
    } catch(e) {
      console.error('❌ KPI fetch error:', e);
      setLoadMsg('Error: ' + e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  // Auto-load KPIs as soon as Dashboard mounts (data is already in DB)
  useEffect(() => {
    console.log('📊 Dashboard mounted. Data is in DB. Loading KPIs…');
    loadAll(filters);
  }, []); // runs once on mount

  const ch = (k, v) => setFilters(p => ({ ...p, [k]: v }));
  const apply = () => loadAll(filters);

  const bvOpts  = [...new Set([...BUILD_VERSIONS,  ...(dynOpts.buildVersions||[])])].sort();
  const lccOpts = [...new Set([...LCC_REVISIONS,   ...(dynOpts.lccRevisions ||[])])].sort();

  const meta = {
    fileCount    : uploadResult?.files?.length || 0,
    totalRaw     : uploadResult?.totalRawRows  || 0,
    totalInserted: uploadResult?.totalInserted || 0,
  };

  return (
    <div style={{ minHeight:'100vh', background:`radial-gradient(ellipse at 20% 20%,rgba(59,130,246,0.08) 0%,transparent 50%),radial-gradient(ellipse at 80% 80%,rgba(139,92,246,0.06) 0%,transparent 50%),${C.bg}`, display:'flex', flexDirection:'column' }}>

      {/* ── TOPBAR ── */}
      <header style={{ height:58, background:'rgba(7,9,26,0.95)', borderBottom:`1px solid rgba(255,255,255,0.08)`, backdropFilter:'blur(20px)', display:'flex', alignItems:'center', justifyContent:'space-between', padding:'0 20px', position:'sticky', top:0, zIndex:400, flexShrink:0 }}>
        <div style={{ display:'flex', alignItems:'center', gap:14 }}>
          <button onClick={()=>setSidebar(p=>!p)} style={{ background:'none', border:'none', cursor:'pointer', padding:4, color:C.text2 }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
          </button>
          <div style={{ width:32, height:32, borderRadius:9, background:`linear-gradient(135deg,${C.blue},${C.purple})`, display:'flex', alignItems:'center', justifyContent:'center', boxShadow:`0 0 20px ${C.blue}44` }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>
          </div>
          <div>
            <div style={{ fontSize:15, fontWeight:700, background:`linear-gradient(90deg,${C.blue2},${C.cyan},${C.purple2})`, WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent' }}>HSCT Analytics Dashboard</div>
            <div style={{ fontSize:10, color:C.text3, fontFamily:'monospace' }}>
              {meta.fileCount} file{meta.fileCount!==1?'s':''} stored in SQLite ·
              <span style={{ color:C.green2 }}> {fmtNum(meta.totalInserted)} distinct sessions</span>
              <span style={{ color:C.text3 }}> · {fmtNum(meta.totalRaw-meta.totalInserted)} dupes removed</span>
            </div>
          </div>
        </div>

        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          {/* Flow indicator */}
          <div style={{ display:'flex', alignItems:'center', gap:6, background:'rgba(255,255,255,0.04)', border:`1px solid rgba(255,255,255,0.1)`, borderRadius:8, padding:'5px 12px' }}>
            <span style={{ fontSize:10, color:C.green2 }}>① CSV Uploaded</span>
            <span style={{ fontSize:10, color:C.text3 }}>→</span>
            <span style={{ fontSize:10, color:C.green2 }}>② Stored in SQLite</span>
            <span style={{ fontSize:10, color:C.text3 }}>→</span>
            <span style={{ fontSize:10, color: loading?C.amber2:C.green2 }}>③ {loading?'Querying DB…':'KPIs Loaded ✓'}</span>
          </div>

          {loading && <div style={{ width:16, height:16, borderRadius:'50%', border:`2px solid rgba(255,255,255,0.1)`, borderTopColor:C.blue, animation:'spin 0.8s linear infinite' }} />}

          <button onClick={apply} style={{ display:'flex', alignItems:'center', gap:5, background:'rgba(255,255,255,0.06)', border:`1px solid rgba(255,255,255,0.1)`, borderRadius:8, padding:'6px 12px', color:C.blue2, fontSize:11, fontWeight:600, cursor:'pointer', fontFamily:'inherit' }}>⟳ Refresh</button>
          <button onClick={()=>window.open(exportUrl(filters))} style={{ display:'flex', alignItems:'center', gap:5, background:`${C.green2}18`, border:`1px solid ${C.green2}30`, borderRadius:8, padding:'6px 12px', color:C.green2, fontSize:11, fontWeight:600, cursor:'pointer', fontFamily:'inherit' }}>⬇ Excel</button>
          <button onClick={onNewUpload} style={{ display:'flex', alignItems:'center', gap:5, background:'rgba(255,255,255,0.06)', border:`1px solid rgba(255,255,255,0.1)`, borderRadius:8, padding:'6px 12px', color:C.text2, fontSize:11, cursor:'pointer', fontFamily:'inherit' }}>↑ New Upload</button>

          <div style={{ display:'flex', alignItems:'center', gap:5, background:`${C.green2}12`, border:`1px solid ${C.green2}30`, borderRadius:20, padding:'4px 11px' }}>
            <div style={{ width:6, height:6, borderRadius:'50%', background:C.green2, boxShadow:`0 0 6px ${C.green2}` }} />
            <span style={{ fontSize:11, color:C.green2, fontFamily:'monospace', fontWeight:600 }}>Live · {fmtNum(summary?.totalSessions)}</span>
          </div>
        </div>
      </header>

      <div style={{ display:'flex', flex:1, overflow:'hidden' }}>

        {/* ── LEFT SIDEBAR ── */}
        <aside style={{ width:sidebarOpen?245:0, minWidth:sidebarOpen?245:0, overflow:'hidden', transition:'width .25s,min-width .25s', background:'rgba(7,9,26,0.7)', borderRight:`1px solid rgba(255,255,255,0.08)`, backdropFilter:'blur(20px)', flexShrink:0, overflowY:'auto' }}>
          <div style={{ padding:'14px 14px 24px', minWidth:245 }}>

            <SidebarSection title="Build Version">
              <CheckList options={bvOpts} selected={filters.buildVersions} onChange={v=>ch('buildVersions',v)} color={C.blue2} />
            </SidebarSection>

            <SidebarSection title="LCC Software Revision">
              <CheckList options={lccOpts} selected={filters.lccRevisions} onChange={v=>ch('lccRevisions',v)} color={C.green2} maxHeight={180} />
            </SidebarSection>

            <SidebarSection title="Thresholds">
              <SliderRow label="HSCT Start" value={filters.hsctStart} min={0} max={10} step={0.5} unit="s" color={C.cyan}    onChange={v=>ch('hsctStart',v)} />
              <SliderRow label="HSCT End"   value={filters.hsctEnd}   min={1} max={30} step={0.5} unit="s" color={C.blue2}   onChange={v=>ch('hsctEnd',v)} />
              <SliderRow label="Login ≤"    value={filters.loginThr}  min={0.5} max={10} step={0.5} unit="s" color={C.purple2} onChange={v=>ch('loginThr',v)} />
              <SliderRow label="Last Days"  value={filters.lastDays}  min={0} max={365} step={1} unit="d" color={C.amber2}  onChange={v=>ch('lastDays',v)} note="0 = all dates" />
            </SidebarSection>

            <SidebarSection title="Date Range">
              {[['From','fromDate'],['To','toDate']].map(([l,k])=>(
                <div key={k} style={{ marginBottom:8 }}>
                  <div style={{ fontSize:9, color:C.text3, marginBottom:3, textTransform:'uppercase', letterSpacing:'.4px' }}>{l}</div>
                  <input type="date" value={filters[k]} onChange={e=>ch(k,e.target.value)}
                    style={{ width:'100%', background:'rgba(255,255,255,0.06)', border:`1px solid rgba(255,255,255,0.1)`, borderRadius:7, padding:'6px 9px', color:C.text, fontSize:11, fontFamily:'monospace', outline:'none', colorScheme:'dark' }}
                  />
                </div>
              ))}
            </SidebarSection>

            <SidebarSection title="Data in DB">
              <div style={{ display:'flex', flexDirection:'column', gap:5 }}>
                {(uploadResult?.files||[]).filter(f=>f.status==='ok').map((f,i)=>(
                  <div key={i} style={{ background:'rgba(255,255,255,0.04)', borderRadius:7, padding:'7px 10px' }}>
                    <div style={{ fontSize:10, color:C.green2, fontWeight:600 }}>Day {i+1} ✓</div>
                    <div style={{ fontSize:9, color:C.text3, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{f.file}</div>
                    <div style={{ fontSize:9, color:C.blue2, fontFamily:'monospace', marginTop:2 }}>{fmtNum(f.inserted)} distinct sessions</div>
                  </div>
                ))}
              </div>
            </SidebarSection>

            <button onClick={apply} style={{ width:'100%', marginTop:8, background:`linear-gradient(135deg,${C.blue},${C.purple})`, border:'none', borderRadius:9, padding:'10px', fontSize:12, fontWeight:700, color:'white', cursor:'pointer', boxShadow:`0 4px 16px ${C.blue}44` }}>
              Apply & Query DB
            </button>
          </div>
        </aside>

        {/* ── MAIN CONTENT ── */}
        <main style={{ flex:1, overflowY:'auto', padding:'18px 20px 52px' }}>

          {/* Tabs */}
          <div style={{ display:'flex', gap:4, marginBottom:18, background:'rgba(255,255,255,0.04)', borderRadius:10, padding:4, width:'fit-content' }}>
            {TABS.map(t=>(
              <button key={t} onClick={()=>setTab(t)} style={{ padding:'7px 18px', border:'none', borderRadius:8, background:tab===t?`linear-gradient(135deg,${C.blue},${C.purple})`:'transparent', color:tab===t?'white':C.text3, fontFamily:'Inter,sans-serif', fontSize:12, fontWeight:600, cursor:'pointer', transition:'all .2s' }}>
                {t}
              </button>
            ))}
          </div>

          {/* Loading state */}
          {loading && (
            <div style={{ ...glassCard, marginBottom:16, display:'flex', alignItems:'center', gap:12 }}>
              <div style={{ width:20, height:20, borderRadius:'50%', border:`2px solid rgba(255,255,255,0.1)`, borderTopColor:C.blue, animation:'spin 0.8s linear infinite', flexShrink:0 }} />
              <span style={{ color:C.text2, fontSize:13 }}>{loadMsg || 'Querying SQLite database…'}</span>
            </div>
          )}

          {!summary && !loading ? (
            <div style={{ display:'flex', alignItems:'center', justifyContent:'center', height:300, flexDirection:'column', gap:12 }}>
              <span style={{ fontSize:14, color:C.text3 }}>No data yet. Upload files to begin.</span>
            </div>
          ) : summary && (
            <>
              {tab==='Overview'    && <OverviewTab summary={summary} trend={trend} fallback={fallback} hsctDist={hsctDist} uploadResult={uploadResult} />}
              {tab==='Trends'      && <TrendsTab   trend={trend} fallback={fallback} filters={filters} />}
              {tab==='Daily Table' && <TableTab    trend={trend} filters={filters} />}
              {tab==='Fallback'    && <FBTab       fallback={fallback} />}
            </>
          )}
        </main>
      </div>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );
}

// ── Sidebar helpers ────────────────────────────────────────────────
function SidebarSection({ title, children }) {
  return (
    <div style={{ marginBottom:18 }}>
      <div style={{ fontSize:9, fontWeight:700, textTransform:'uppercase', letterSpacing:'1px', color:C.text3, marginBottom:9, paddingBottom:5, borderBottom:`1px solid rgba(255,255,255,0.06)` }}>{title}</div>
      {children}
    </div>
  );
}

function SliderRow({ label, value, min, max, step, unit, color, onChange, note }) {
  return (
    <div style={{ marginBottom:12 }}>
      <div style={{ display:'flex', justifyContent:'space-between', marginBottom:5 }}>
        <div>
          <span style={{ fontSize:10, color:C.text2 }}>{label}</span>
          {note && <span style={{ fontSize:9, color:C.text3, marginLeft:5 }}>({note})</span>}
        </div>
        <span style={{ fontFamily:'monospace', fontSize:11, fontWeight:700, color }}>{value}{unit}</span>
      </div>
      <input type="range" min={min} max={max} step={step} value={value}
        onChange={e=>onChange(Number(e.target.value))}
        style={{ width:'100%', accentColor:color, cursor:'pointer' }}
      />
    </div>
  );
}

function CheckList({ options, selected, onChange, color, maxHeight=150 }) {
  const toggle = v => onChange(selected.includes(v)?selected.filter(x=>x!==v):[...selected,v]);
  return (
    <div style={{ maxHeight, overflowY:'auto', display:'flex', flexDirection:'column', gap:3 }}>
      <div style={{ display:'flex', gap:8, marginBottom:5 }}>
        <button onClick={()=>onChange(options)} style={{ fontSize:9, color, background:'none', border:'none', cursor:'pointer', fontWeight:600 }}>Select All</button>
        <button onClick={()=>onChange([])}       style={{ fontSize:9, color:C.rose, background:'none', border:'none', cursor:'pointer' }}>Clear</button>
      </div>
      {options.map(v=>(
        <label key={v} onClick={()=>toggle(v)} style={{ display:'flex', alignItems:'center', gap:7, padding:'4px 6px', cursor:'pointer', borderRadius:5, background:selected.includes(v)?`${color}12`:'transparent' }}>
          <div style={{ width:12, height:12, borderRadius:3, border:`1.5px solid ${selected.includes(v)?color:'rgba(255,255,255,0.2)'}`, background:selected.includes(v)?color:'transparent', flexShrink:0, display:'flex', alignItems:'center', justifyContent:'center' }}>
            {selected.includes(v)&&<svg width="8" height="8" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3.5"><polyline points="20 6 9 17 4 12"/></svg>}
          </div>
          <span style={{ fontSize:10, fontFamily:'monospace', color:selected.includes(v)?color:C.text2 }}>{v}</span>
        </label>
      ))}
    </div>
  );
}

// ── Overview Tab ───────────────────────────────────────────────────
function OverviewTab({ summary:s, trend, fallback, hsctDist, uploadResult }) {
  const kpis = [
    { label:`HSCT ≤${s.hsctEnd}s (Last ${s.lastDays>0?s.lastDays+'d':'All'})`, value:s.hsctRate,          isPercent:true,  accentColor:C.blue2,   tag:'KPI 6',  sub:'Sessions within HSCT threshold',              countLabel:'HSCT Count',     countValue:s.hsctCount },
    { label:'Total Sessions',                                                    value:s.totalSessions,     isPercent:false, accentColor:C.text,    tag:'KPI 7',  sub:'COUNT(DISTINCT SessionId)' },
    { label:'Plant %',                                                           value:s.plantAttachRate,   isPercent:true,  accentColor:C.green2,  tag:'KPI 8',  sub:'Plant / Total' },
    { label:'Non-Plant %',                                                       value:s.nonPlantRate,      isPercent:true,  accentColor:C.amber2,  tag:'KPI 9',  sub:'Non-Plant / Total' },
    { label:'Total Plant Sessions',                                              value:s.plantSessions,     isPercent:false, accentColor:C.green2,  tag:'KPI 10', sub:'COUNT(DISTINCT WHERE PLANT)' },
    { label:'Total Non-Plant Sessions',                                          value:s.nonPlantSessions,  isPercent:false, accentColor:C.amber2,  tag:'KPI 11', sub:'COUNT(DISTINCT WHERE NON-PLANT)' },
    { label:`HSCT Sessions [${s.hsctStart}–${s.hsctEnd}s]`,                     value:s.hsctCount,         isPercent:false, accentColor:C.blue2,   tag:'KPI 12', sub:'BETWEEN HSCT_START AND HSCT_END' },
    { label:`Login Success ≤${s.loginThr}s`,                                    value:s.loginRate,         isPercent:true,  accentColor:C.purple2, tag:'KPI 4',  sub:'Login / Sessions with Login',                  countLabel:'Login Count',    countValue:s.loginCount },
    { label:`Plant HSCT % ≤${s.hsctEnd}s`,                                      value:s.plantHsctRate,     isPercent:true,  accentColor:C.green2,  tag:'KPI 13', sub:'Plant HSCT / Total Plant',                     countLabel:'Plant HSCT Cnt', countValue:s.plantHsctCount },
    { label:`Non-Plant MQTT HSCT % ≤${s.hsctEnd}s`,                             value:s.nonPlantHsctRate,  isPercent:true,  accentColor:C.amber2,  tag:'KPI 14', sub:'NP MQTT HSCT / Total NP',                      countLabel:'NP HSCT Cnt',    countValue:s.nonPlantHsctCount },
    { label:'Total Plant HSCT Sessions',                                         value:s.plantHsctCount,    isPercent:false, accentColor:C.green2,  tag:'KPI 15', sub:'COUNT(DISTINCT PLANT & HSCT in range)' },
    { label:'Total Non-Plant HSCT Sessions',                                     value:s.nonPlantHsctCount, isPercent:false, accentColor:C.amber2,  tag:'KPI 16', sub:'COUNT(DISTINCT NON-PLANT & MQTT HSCT)' },
  ];

  return (
    <>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(220px,1fr))', gap:12, marginBottom:18 }}>
        {kpis.map((k,i)=><KPICard key={i} {...k} />)}
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'1.4fr 1fr', gap:12, marginBottom:12 }}>
        <SessionsVolumeChart data={trend} />
        <HSCTHealthGauge summary={s} />
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:12, marginBottom:12 }}>
        <HSCTDistributionChart data={hsctDist} />
        <PlantDonutChart plant={s.plantSessions} nonPlant={s.nonPlantSessions} total={s.totalSessions} />
        <SessionHeatmap trend={trend} />
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12, marginBottom:16 }}>
        <FallbackChart data={fallback} />
        <KPITrendChart data={trend} hsctEnd={s.hsctEnd} loginThr={s.loginThr} />
      </div>
      {/* Definitions */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12 }}>
        {[
          { t:'HSCT',                color:C.blue2,   def:'System_HomeScreenConstructionTime − SessionStartTime', note:'Time to construct Home Screen in seconds.' },
          { t:'Plant Classification',color:C.green2,  def:'FallbackStartTime IS NULL/empty/nan → PLANT, else NON-PLANT', note:'Sessions without fallback = Plant.' },
          { t:'Plant Attachment Rate',color:C.purple2, def:'Plant Sessions ÷ Total Sessions × 100', note:'Share of sessions classified as Plant.' },
        ].map(d=>(
          <div key={d.t} style={{ ...glassCard }}>
            <div style={{ position:'absolute', top:0, left:0, right:0, height:2, background:d.color, borderRadius:'16px 16px 0 0' }} />
            <div style={{ fontSize:10, fontWeight:700, textTransform:'uppercase', letterSpacing:'.7px', color:d.color, marginBottom:7 }}>{d.t}</div>
            <div style={{ fontSize:11, fontFamily:'monospace', color:C.text2, marginBottom:5, lineHeight:1.5 }}>{d.def}</div>
            <div style={{ fontSize:10, color:C.text3 }}>{d.note}</div>
          </div>
        ))}
      </div>
    </>
  );
}

function TrendsTab({ trend, fallback, filters }) {
  return (
    <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
      <KPITrendChart data={trend} hsctEnd={filters.hsctEnd} loginThr={filters.loginThr} />
      <SessionsVolumeChart data={trend} />
      <FallbackChart data={fallback} />
    </div>
  );
}

function TableTab({ trend, filters }) {
  return (
    <div style={{ ...glassCard }}>
      <div style={{ position:'absolute', top:0, left:0, right:0, height:2, background:`linear-gradient(90deg,${C.blue},${C.purple})`, borderRadius:'16px 16px 0 0' }} />
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:14 }}>
        <span style={{ fontSize:10, fontWeight:700, textTransform:'uppercase', letterSpacing:'.8px', color:C.text3 }}>Daily KPI Table — Queried from SQLite</span>
        <span style={{ fontSize:9, fontFamily:'monospace', background:'rgba(255,255,255,0.06)', border:`1px solid rgba(255,255,255,0.1)`, borderRadius:5, padding:'2px 8px', color:C.text3 }}>COUNT(DISTINCT SessionId)</span>
      </div>
      <KPITable trend={trend} hsctEnd={filters.hsctEnd} loginThr={filters.loginThr} hsctStart={filters.hsctStart} />
    </div>
  );
}

function FBTab({ fallback }) {
  return (
    <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
      <FallbackChart data={fallback} />
      {fallback.length>0 && (
        <div style={{ ...glassCard }}>
          <div style={{ position:'absolute', top:0, left:0, right:0, height:2, background:`linear-gradient(90deg,${C.rose},${C.pink})`, borderRadius:'16px 16px 0 0' }} />
          <div style={{ fontSize:10, fontWeight:700, textTransform:'uppercase', letterSpacing:'.8px', color:C.text3, marginBottom:14 }}>Top 5 Fallback Causes — FallbackCause ≠ nan</div>
          <table style={{ width:'100%', borderCollapse:'collapse', fontSize:12 }}>
            <thead>
              <tr style={{ borderBottom:`1px solid rgba(255,255,255,0.1)` }}>
                {['Rank','FallbackCause','COUNT(DISTINCT SessionId)'].map(h=>(
                  <th key={h} style={{ padding:'9px 14px', textAlign:h.includes('COUNT')?'right':'left', fontSize:9, fontWeight:700, textTransform:'uppercase', color:C.text3, fontFamily:'monospace' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {fallback.map((f,i)=>{
                const COLORS=[C.rose,C.amber2,C.purple2,C.cyan,C.green2];
                return (
                  <tr key={i} style={{ borderBottom:`1px solid rgba(255,255,255,0.05)`, background:i%2===0?'transparent':'rgba(255,255,255,0.02)' }}>
                    <td style={{ padding:'9px 14px', fontFamily:'monospace', fontWeight:700, color:COLORS[i], fontSize:16 }}>#{i+1}</td>
                    <td style={{ padding:'9px 14px', fontFamily:'monospace', color:C.text }}>{f.cause}</td>
                    <td style={{ padding:'9px 14px', fontFamily:'monospace', fontWeight:700, color:COLORS[i], textAlign:'right', fontSize:16 }}>{fmtNum(f.total)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
