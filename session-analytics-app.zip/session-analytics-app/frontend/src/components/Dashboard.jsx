import { useState, useEffect, useCallback } from 'react';
import { C, panel, fmt, fmtNum } from '../styles/theme';
import FilterBar from './FilterBar';
import KPICard from './KPICard';
import KPITable from './KPITable';
import { KPITrendChart, SessionsVolumeChart, PlantDonutChart, FallbackChart, RateBreakdownChart } from './Charts';
import { fetchSummary, fetchTrend, fetchFallback, fetchFilters, exportUrl } from '../api';

const TABS = ['Overview', 'Trends', 'Daily Table', 'Fallback'];

export default function Dashboard({ uploadResult, onNewUpload }) {
  const [tab, setTab]           = useState('Overview');
  const [summary, setSummary]   = useState(null);
  const [trend, setTrend]       = useState([]);
  const [fallback, setFallback] = useState([]);
  const [dynOptions, setDynOptions] = useState({});
  const [loading, setLoading]   = useState(false);
  const [filters, setFilters]   = useState({
    batch         : uploadResult?.batchId || null,
    hsctStart     : 0,
    hsctEnd       : 5,
    loginThr      : 1,
    lastDays      : 0,
    buildVersions : [],
    lccRevisions  : [],
    fromDate      : '',
    toDate        : '',
  });

  useEffect(() => {
    if (uploadResult?.filterOptions) setDynOptions(uploadResult.filterOptions);
    else if (filters.batch) fetchFilters(filters.batch).then(setDynOptions).catch(console.error);
  }, [uploadResult]);

  const loadAll = useCallback(async (f) => {
    setLoading(true);
    try {
      const [s, t, fb] = await Promise.all([fetchSummary(f), fetchTrend(f), fetchFallback(f)]);
      setSummary(s); setTrend(t); setFallback(fb);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { loadAll(filters); }, []);

  const change = (key, val) => setFilters(prev => ({ ...prev, [key]: val }));
  const apply  = () => loadAll(filters);
  const doExport = () => {
    const url = exportUrl(filters);
    const a = document.createElement('a'); a.href = url;
    a.download = `session-analytics-${new Date().toISOString().slice(0,10)}.xlsx`; a.click();
  };

  const meta = { fileCount: uploadResult?.files?.length || 0, totalRaw: uploadResult?.totalRawRows || 0, totalInserted: uploadResult?.totalInserted || 0 };

  return (
    <div style={{ minHeight:'100vh', background:C.bg }}>

      {/* ── Topbar ── */}
      <header style={{ height:56, background:'rgba(13,0,24,.97)', borderBottom:`1px solid ${C.border2}`, display:'flex', alignItems:'center', justifyContent:'space-between', padding:'0 24px', position:'sticky', top:0, zIndex:400 }}>
        <div style={{ display:'flex', alignItems:'center', gap:12 }}>
          <div style={{ width:34, height:34, borderRadius:9, background:`linear-gradient(135deg,${C.pink},${C.purple})`, display:'flex', alignItems:'center', justifyContent:'center', boxShadow:`0 0 20px ${C.pink}44` }}>
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>
          </div>
          <div>
            <div style={{ fontSize:15, fontWeight:700, background:`linear-gradient(90deg,${C.pink2},${C.pink},${C.purple})`, WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent' }}>Session Analytics Dashboard</div>
            <div style={{ fontSize:10, color:C.text3, fontFamily:'monospace' }}>Lennox International · React + Express + SQLite</div>
          </div>
        </div>
        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          {loading && <span style={{ fontSize:11, color:C.pink, fontFamily:'monospace' }}>● Computing KPIs…</span>}
          <div style={{ display:'flex', alignItems:'center', gap:5, background:`${C.mint}12`, border:`1px solid ${C.mint}30`, borderRadius:20, padding:'4px 12px' }}>
            <div style={{ width:6, height:6, borderRadius:'50%', background:C.mint, boxShadow:`0 0 6px ${C.mint}`, animation:'pulse 2s infinite' }} />
            <span style={{ fontSize:11, color:C.mint, fontFamily:'monospace', fontWeight:600 }}>
              Live · {fmtNum(summary?.totalSessions)} sessions
            </span>
          </div>
        </div>
      </header>

      {/* ── Filter Bar ── */}
      <FilterBar filters={filters} dynamicOptions={dynOptions} onChange={change} onApply={apply} onExport={doExport} onNewUpload={onNewUpload} meta={meta} />

      {/* ── Active Filters Summary ── */}
      {(filters.buildVersions.length > 0 || filters.lccRevisions.length > 0 || filters.lastDays > 0) && (
        <div style={{ background:C.surface2, borderBottom:`1px solid ${C.border}`, padding:'6px 22px', display:'flex', alignItems:'center', gap:8, flexWrap:'wrap' }}>
          <span style={{ fontSize:10, color:C.text3 }}>Active filters:</span>
          {filters.buildVersions.map(v => <Chip key={v} label={v} color={C.pink} onRemove={() => change('buildVersions', filters.buildVersions.filter(x=>x!==v))} />)}
          {filters.lccRevisions.map(v => <Chip key={v} label={v} color={C.mint} onRemove={() => change('lccRevisions', filters.lccRevisions.filter(x=>x!==v))} />)}
          {filters.lastDays > 0 && <Chip label={`Last ${filters.lastDays} days`} color={C.amber} onRemove={() => change('lastDays', 0)} />}
          <button onClick={() => { change('buildVersions',[]); change('lccRevisions',[]); change('lastDays',0); }} style={{ fontSize:10, color:C.rose, background:'none', border:'none', cursor:'pointer', marginLeft:4 }}>Clear all</button>
        </div>
      )}

      {/* ── Tab Bar ── */}
      <div style={{ display:'flex', borderBottom:`1px solid ${C.border}`, padding:'0 22px', background:C.surface, position:'sticky', top:100, zIndex:200 }}>
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)} style={{ padding:'11px 20px', border:'none', background:'transparent', color: tab===t ? C.pink : C.text3, fontFamily:'Inter,sans-serif', fontSize:12, fontWeight: tab===t ? 700 : 400, cursor:'pointer', borderBottom: tab===t ? `2px solid ${C.pink}` : '2px solid transparent', transition:'all .15s' }}>
            {t}
          </button>
        ))}
      </div>

      {/* ── Content ── */}
      <div style={{ padding:'20px 22px 60px', maxWidth:1800, margin:'0 auto' }}>
        {!summary ? (
          <div style={{ display:'flex', alignItems:'center', justifyContent:'center', height:300, flexDirection:'column', gap:12 }}>
            <div style={{ width:40, height:40, borderRadius:'50%', border:`3px solid ${C.border2}`, borderTopColor:C.pink, animation:'spin 1s linear infinite' }} />
            <span style={{ color:C.text3, fontSize:13 }}>{loading ? 'Loading KPIs…' : 'Upload files to get started'}</span>
          </div>
        ) : (
          <>
            {tab === 'Overview' && <OverviewTab summary={summary} trend={trend} fallback={fallback} filters={filters} uploadResult={uploadResult} />}
            {tab === 'Trends'   && <TrendsTab   trend={trend}    filters={filters} />}
            {tab === 'Daily Table' && <TableTab trend={trend} filters={filters} />}
            {tab === 'Fallback' && <FallbackTab fallback={fallback} />}
          </>
        )}
      </div>

      <style>{`
        @keyframes spin { to { transform:rotate(360deg); } }
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.3} }
      `}</style>
    </div>
  );
}

// ── Chip ──────────────────────────────────────────────────────────
function Chip({ label, color, onRemove }) {
  return (
    <span style={{ display:'inline-flex', alignItems:'center', gap:4, fontSize:10, fontFamily:'monospace', background:`${color}14`, color, border:`1px solid ${color}33`, borderRadius:5, padding:'2px 8px' }}>
      {label}
      <button onClick={onRemove} style={{ background:'none', border:'none', color, cursor:'pointer', fontSize:12, lineHeight:1, padding:0 }}>×</button>
    </span>
  );
}

// ── Section Divider ───────────────────────────────────────────────
function Sec({ label }) {
  return (
    <div style={{ display:'flex', alignItems:'center', gap:12, padding:'16px 0 10px' }}>
      <span style={{ fontSize:10, fontWeight:700, textTransform:'uppercase', letterSpacing:'1px', color:C.text3, whiteSpace:'nowrap' }}>{label}</span>
      <div style={{ flex:1, height:1, background:`linear-gradient(90deg,${C.border2},transparent)` }} />
    </div>
  );
}

// ── Count Strip ───────────────────────────────────────────────────
function CountStrip({ s }) {
  const cells = [
    { label:'Total Sessions (DISTINCT)',    val: s.totalSessions,    color: C.pink   },
    { label:'Plant Sessions',               val: s.plantSessions,    color: C.mint   },
    { label:'Non-Plant Sessions',           val: s.nonPlantSessions, color: C.amber  },
    { label:'% Plant',                      val: fmt(s.plantRate),   color: C.mint   },
    { label:'% Non-Plant',                  val: fmt(s.nonPlantRate),color: C.amber  },
    { label:`HSCT [${s.hsctStart}–${s.hsctEnd}s] Count`, val: s.hsctCount,      color: C.pink   },
    { label:'Plant HSCT Count',             val: s.plantHsctCount,   color: C.mint   },
    { label:'NP HSCT Count',                val: s.nonPlantHsctCount,color: C.amber  },
    { label:`Login ≤${s.loginThr}s Count`,  val: s.loginCount,       color: C.lav    },
    { label:'Sessions with Login',          val: s.loginTotal,       color: C.purple },
  ];
  return (
    <div style={{ display:'flex', border:`1px solid ${C.border}`, borderRadius:12, overflow:'hidden', flexWrap:'wrap' }}>
      {cells.map((c,i) => (
        <div key={i} style={{ flex:'1 1 110px', padding:'13px 14px', borderRight: i<cells.length-1?`1px solid ${C.border}`:'none', display:'flex', flexDirection:'column', gap:3, background: i%2===0 ? C.surface : `rgba(255,255,255,.012)` }}>
          <div style={{ fontSize:9, color:C.text3, textTransform:'uppercase', letterSpacing:'.3px', fontWeight:600, lineHeight:1.4 }}>{c.label}</div>
          <div style={{ fontFamily:'monospace', fontSize:15, fontWeight:700, color:c.color }}>{typeof c.val==='number' ? fmtNum(c.val) : c.val}</div>
        </div>
      ))}
    </div>
  );
}

// ── Infographic Row ───────────────────────────────────────────────
function InfographicRow({ summary: s }) {
  const items = [
    { label:'Plant Attachment Rate', formula:'Plant / Total', value: s.plantAttachRate, color: C.rose,   icon:'🌱' },
    { label:`% HSCT [${s.hsctStart}–${s.hsctEnd}s]`, formula:'HSCT BETWEEN Start AND End / Total', value: s.hsctRate, color: C.pink, icon:'⚡' },
    { label:`% Plant HSCT ≤${s.hsctEnd}s`, formula:'Plant HSCT / Total Plant', value: s.plantHsctRate, color: C.mint, icon:'🏭' },
    { label:`% NP MQTT HSCT ≤${s.hsctEnd}s`, formula:'NP MQTT HSCT / Total NP', value: s.nonPlantHsctRate, color: C.amber, icon:'📡' },
    { label:`% Login ≤${s.loginThr}s`, formula:'Login BETWEEN 0 AND thr / Sessions with Login', value: s.loginRate, color: C.lav, icon:'🔐' },
  ];

  return (
    <div style={{ display:'grid', gridTemplateColumns:'repeat(5, 1fr)', gap:12 }}>
      {items.map((item, i) => (
        <div key={i} style={{ ...panel, textAlign:'center', padding:'22px 16px' }}>
          <div style={{ position:'absolute', top:0, left:0, right:0, height:3, background:item.color, borderRadius:'14px 14px 0 0' }} />
          {/* Circular progress */}
          <div style={{ position:'relative', width:90, height:90, margin:'0 auto 14px' }}>
            <svg width="90" height="90" viewBox="0 0 90 90">
              <circle cx="45" cy="45" r="36" fill="none" stroke={C.surface2} strokeWidth="7" />
              <circle cx="45" cy="45" r="36" fill="none" stroke={item.color} strokeWidth="7"
                strokeLinecap="round"
                strokeDasharray={`${2*Math.PI*36}`}
                strokeDashoffset={`${2*Math.PI*36*(1-(item.value||0)/100)}`}
                transform="rotate(-90 45 45)"
                style={{ transition:'stroke-dashoffset 1.3s cubic-bezier(.22,1,.36,1)' }}
              />
            </svg>
            <div style={{ position:'absolute', inset:0, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center' }}>
              <span style={{ fontSize:14, fontFamily:'monospace', fontWeight:700, color:item.color, lineHeight:1 }}>{fmt(item.value)}</span>
            </div>
          </div>
          <div style={{ fontSize:11, fontWeight:700, color:C.text, marginBottom:5, lineHeight:1.3 }}>{item.icon} {item.label}</div>
          <div style={{ fontSize:9, color:C.text3, fontFamily:'monospace', lineHeight:1.4 }}>{item.formula}</div>
        </div>
      ))}
    </div>
  );
}

// ── Overview Tab ──────────────────────────────────────────────────
function OverviewTab({ summary: s, trend, fallback, filters, uploadResult }) {
  return (
    <>
      <Sec label="Infographics — Corrected Final Formulas" />
      <InfographicRow summary={s} />

      <Sec label="KPI Cards — COUNT(DISTINCT SessionId)" />
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:14, marginBottom:14 }}>
        <KPICard label="Total Sessions" value={s.totalSessions} accentColor={C.pink} tag="COUNT(DISTINCT SessionId)" />
        <KPICard label="Plant Sessions" value={s.plantSessions} accentColor={C.mint} tag={fmt(s.plantRate)+' of total'} sub="FallbackStartTime = null/nan" />
        <KPICard label="Non-Plant Sessions" value={s.nonPlantSessions} accentColor={C.amber} tag={fmt(s.nonPlantRate)+' of total'} sub="FallbackStartTime present" />
        <KPICard label="Plant Attachment Rate" value={s.plantAttachRate} isPercent accentColor={C.rose} tag="Formula 1" sub="Plant / Total" />
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:14, marginBottom:14 }}>
        <KPICard label={`% Total HSCT [${s.hsctStart}–${s.hsctEnd}s]`} value={s.hsctRate} isPercent accentColor={C.pink} tag="Formula 2" sub="HSCT BETWEEN Start AND End / Total" countLabel="Count" countValue={s.hsctCount} />
        <KPICard label={`% Plant HSCT ≤${s.hsctEnd}s`} value={s.plantHsctRate} isPercent accentColor={C.mint} tag="Formula 3" sub="Plant HSCT / Total Plant" countLabel="Count" countValue={s.plantHsctCount} />
        <KPICard label={`% NP MQTT HSCT ≤${s.hsctEnd}s`} value={s.nonPlantHsctRate} isPercent accentColor={C.amber} tag="Formula 4" sub="NP MQTT HSCT / Total NP" countLabel="Count" countValue={s.nonPlantHsctCount} />
        <KPICard label={`% Login ≤${s.loginThr}s`} value={s.loginRate} isPercent accentColor={C.lav} tag="Formula 5" sub="Login BETWEEN 0 AND thr / Sessions with Login" countLabel="Count" countValue={s.loginCount} />
      </div>

      <Sec label="Session Counts — KPI 2 Distribution" />
      <CountStrip s={s} />

      <Sec label="Charts" />
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:14, marginTop:4 }}>
        <PlantDonutChart plant={s.plantSessions} nonPlant={s.nonPlantSessions} total={s.totalSessions} />
        <RateBreakdownChart summary={s} hsctEnd={s.hsctEnd} loginThr={s.loginThr} />
        <FallbackChart data={fallback} />
      </div>

      {uploadResult?.files?.length > 0 && (
        <>
          <Sec label="Uploaded Files" />
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(200px,1fr))', gap:12 }}>
            {uploadResult.files.filter(f=>f.status==='ok').map((f,i) => (
              <div key={i} style={{ ...panel, padding:'13px 16px' }}>
                <div style={{ position:'absolute', top:0, left:0, right:0, height:2, background:`linear-gradient(90deg,${C.mint},${C.cyan})`, borderRadius:'14px 14px 0 0' }} />
                <div style={{ fontSize:9, color:C.text3, textTransform:'uppercase', fontWeight:600, marginBottom:3 }}>Day {i+1}</div>
                <div style={{ fontSize:11, color:C.text, fontWeight:600, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', marginBottom:6 }}>{f.file}</div>
                <div style={{ display:'flex', gap:8, fontSize:10 }}>
                  <span style={{ color:C.mint, fontFamily:'monospace' }}>{fmtNum(f.inserted)} distinct</span>
                  <span style={{ color:C.text3 }}>/ {fmtNum(f.rawRows)} raw</span>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </>
  );
}

function TrendsTab({ trend, filters }) {
  return (
    <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
      <KPITrendChart data={trend} hsctEnd={filters.hsctEnd} loginThr={filters.loginThr} />
      <SessionsVolumeChart data={trend} />
    </div>
  );
}

function TableTab({ trend, filters }) {
  return (
    <div style={{ ...panel }}>
      <div style={{ position:'absolute', top:0, left:0, right:0, height:3, background:`linear-gradient(90deg,${C.pink},${C.purple})`, borderRadius:'14px 14px 0 0' }} />
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:14, marginTop:4 }}>
        <span style={{ fontSize:10, fontWeight:700, textTransform:'uppercase', letterSpacing:'.8px', color:C.text3 }}>Per-Date KPI Breakdown</span>
        <span style={{ fontSize:9, fontFamily:'monospace', background:C.surface2, border:`1px solid ${C.border2}`, borderRadius:4, padding:'2px 7px', color:C.text3 }}>Matches reference Excel · COUNT(DISTINCT SessionId)</span>
      </div>
      <KPITable trend={trend} hsctEnd={filters.hsctEnd} loginThr={filters.loginThr} hsctStart={filters.hsctStart} />
    </div>
  );
}

function FallbackTab({ fallback }) {
  return (
    <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
      <FallbackChart data={fallback} />
      {fallback.length > 0 && (
        <div style={{ ...panel }}>
          <div style={{ position:'absolute', top:0, left:0, right:0, height:2, background:`linear-gradient(90deg,${C.rose},${C.pink})`, borderRadius:'14px 14px 0 0' }} />
          <div style={{ fontSize:10, fontWeight:700, textTransform:'uppercase', letterSpacing:'.8px', color:C.text3, marginBottom:14, marginTop:4 }}>Fallback Detail — Top 5 (excl. nan)</div>
          <table style={{ width:'100%', borderCollapse:'collapse', fontSize:12 }}>
            <thead>
              <tr style={{ borderBottom:`1px solid ${C.border2}` }}>
                {['Rank','FallbackCause','COUNT(DISTINCT SessionId)'].map(h=>(
                  <th key={h} style={{ padding:'9px 14px', textAlign: h.includes('COUNT') ? 'right':'left', fontSize:9, fontWeight:700, textTransform:'uppercase', letterSpacing:'.5px', color:C.text3, fontFamily:'monospace' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {fallback.map((f,i)=>{
                const COLORS=[C.pink,C.purple,C.mint,C.amber,C.rose];
                return (
                  <tr key={i} style={{ borderBottom:`1px solid ${C.border}55`, background: i%2===0?'transparent':'rgba(255,255,255,.01)' }}>
                    <td style={{ padding:'9px 14px', fontFamily:'monospace', fontWeight:700, color:COLORS[i], fontSize:14 }}>#{i+1}</td>
                    <td style={{ padding:'9px 14px', fontFamily:'monospace', color:C.text }}>{f.cause}</td>
                    <td style={{ padding:'9px 14px', fontFamily:'monospace', fontWeight:700, color:COLORS[i], textAlign:'right', fontSize:14 }}>{fmtNum(f.total)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
