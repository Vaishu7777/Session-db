import { C, glassCard, fmt, fmtNum } from '../styles/theme';

export default function KPICard({ label, value, isPercent, sub, tag, accentColor, countLabel, countValue, icon }) {
  const col = accentColor || C.blue2;
  return (
    <div style={{
      ...glassCard,
      transition: 'transform .18s, box-shadow .18s',
      cursor: 'default',
    }}
      onMouseEnter={e => { e.currentTarget.style.transform='translateY(-2px)'; e.currentTarget.style.boxShadow=`0 8px 32px ${col}22`; }}
      onMouseLeave={e => { e.currentTarget.style.transform='translateY(0)'; e.currentTarget.style.boxShadow='none'; }}
    >
      {/* Top accent line */}
      <div style={{ position:'absolute', top:0, left:0, right:0, height:2, background:`linear-gradient(90deg,${col},${col}44)`, borderRadius:'16px 16px 0 0' }} />

      {/* Glow blob */}
      <div style={{ position:'absolute', top:-20, right:-20, width:80, height:80, borderRadius:'50%', background:`${col}14`, filter:'blur(20px)', pointerEvents:'none' }} />

      <div style={{ fontSize:10, fontWeight:600, textTransform:'uppercase', letterSpacing:'.8px', color:C.text3, marginBottom:10, display:'flex', alignItems:'center', gap:6 }}>
        {icon && <span style={{ fontSize:13 }}>{icon}</span>}
        {label}
      </div>

      <div style={{ fontFamily:C.mono, fontSize:30, fontWeight:700, color:col, letterSpacing:-1, lineHeight:1, marginBottom:8 }}>
        {isPercent ? fmt(value) : fmtNum(value)}
      </div>

      {(tag || sub) && (
        <div style={{ display:'flex', alignItems:'center', gap:6, flexWrap:'wrap' }}>
          {tag && <span style={{ fontSize:9, fontFamily:'monospace', fontWeight:700, padding:'2px 8px', borderRadius:5, background:`${col}18`, color:col, border:`1px solid ${col}30` }}>{tag}</span>}
          {sub && <span style={{ fontSize:10, color:C.text3 }}>{sub}</span>}
        </div>
      )}

      {countLabel && (
        <div style={{ marginTop:10, paddingTop:8, borderTop:`1px solid rgba(255,255,255,0.06)`, display:'flex', justifyContent:'space-between', alignItems:'center' }}>
          <span style={{ fontSize:10, color:C.text3 }}>{countLabel}</span>
          <span style={{ fontFamily:'monospace', fontSize:12, fontWeight:700, color:col }}>{fmtNum(countValue)}</span>
        </div>
      )}
    </div>
  );
}
