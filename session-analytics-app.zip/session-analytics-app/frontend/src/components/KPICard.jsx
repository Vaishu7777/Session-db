import { C, panel, monoFont, fmt, fmtNum } from '../styles/theme';

export default function KPICard({ label, value, isPercent, tag, tagColor, accentColor, sub, countLabel, countValue }) {
  return (
    <div style={{ ...panel, minHeight: 130 }}>
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 3, background: accentColor, borderRadius: '14px 14px 0 0' }} />
      <div style={{ fontSize: 10, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '.7px', color: C.text3, marginBottom: 10, marginTop: 4 }}>{label}</div>
      <div style={{ fontFamily: monoFont, fontSize: 30, fontWeight: 700, lineHeight: 1, color: accentColor, letterSpacing: -1, marginBottom: 8 }}>
        {isPercent ? fmt(value) : fmtNum(value)}
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
        {tag && (
          <span style={{ fontSize: 9, fontFamily: 'monospace', fontWeight: 700, padding: '2px 8px', borderRadius: 4, background: (tagColor || accentColor) + '18', color: tagColor || accentColor, border: `1px solid ${(tagColor || accentColor)}33` }}>
            {tag}
          </span>
        )}
        {sub && <span style={{ fontSize: 10, color: C.text3 }}>{sub}</span>}
      </div>
      {countLabel && (
        <div style={{ marginTop: 8, paddingTop: 8, borderTop: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ fontSize: 10, color: C.text3 }}>{countLabel}</span>
          <span style={{ fontFamily: monoFont, fontSize: 11, fontWeight: 600, color: C.text2 }}>{fmtNum(countValue)}</span>
        </div>
      )}
    </div>
  );
}
