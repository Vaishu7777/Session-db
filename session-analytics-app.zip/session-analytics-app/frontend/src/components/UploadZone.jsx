import { useState, useRef } from 'react';
import { C } from '../styles/theme';
import { uploadFiles } from '../api';

export default function UploadZone({ onUploaded }) {
  const [drag, setDrag]     = useState(false);
  const [files, setFiles]   = useState([]);
  const [loading, setLoad]  = useState(false);
  const [prog, setProg]     = useState(0);
  const [progMsg, setMsg]   = useState('');
  const [error, setError]   = useState('');
  const ref = useRef();

  const fmtSize = b => b > 1e6 ? (b/1e6).toFixed(1)+'MB' : (b/1e3).toFixed(0)+'KB';

  function pick(list) {
    const arr = Array.from(list).filter(f => /\.(csv|xlsx|xls)$/i.test(f.name));
    if (!arr.length) { setError('Please select .csv, .xlsx, or .xls files'); return; }
    if (arr.length > 5) { setError('Maximum 5 files (one per day)'); return; }
    setFiles(arr); setError('');
  }

  async function handleUpload() {
    if (!files.length) return;
    setLoad(true); setProg(0); setMsg('Uploading…'); setError('');
    try {
      const steps = ['Reading…', 'Parsing CSV…', 'Detecting columns…', 'DISTINCT dedup…', 'Inserting to DB…'];
      let si = 0;
      const iv = setInterval(() => { si++; if(si<steps.length) setMsg(steps[si]); }, 1200);
      const result = await uploadFiles(files, p => setProg(p));
      clearInterval(iv);
      setMsg('Done!');
      setTimeout(() => onUploaded(result), 400);
    } catch(e) {
      setError(e.response?.data?.error || e.message);
      setLoad(false);
    }
  }

  return (
    <div style={{ minHeight:'100vh', display:'flex', flexDirection:'column', background:`radial-gradient(ellipse at 30% 20%, rgba(59,130,246,0.1) 0%, transparent 55%), radial-gradient(ellipse at 80% 80%, rgba(139,92,246,0.08) 0%, transparent 55%), ${C.bg}` }}>
      {/* Topbar */}
      <header style={{ height:58, background:'rgba(7,9,26,0.9)', borderBottom:`1px solid rgba(255,255,255,0.08)`, backdropFilter:'blur(20px)', display:'flex', alignItems:'center', padding:'0 24px', gap:12 }}>
        <div style={{ width:32, height:32, borderRadius:9, background:`linear-gradient(135deg,${C.blue},${C.purple})`, display:'flex', alignItems:'center', justifyContent:'center', boxShadow:`0 0 20px ${C.blue}44` }}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>
        </div>
        <span style={{ fontSize:15, fontWeight:700, background:`linear-gradient(90deg,${C.blue2},${C.cyan},${C.purple2})`, WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent' }}>HSCT Analytics Dashboard</span>
        <span style={{ fontSize:10, color:C.text3, fontFamily:'monospace', marginLeft:4 }}>React + Express + SQLite · All KPIs use COUNT(DISTINCT SessionId)</span>
      </header>

      {/* Upload area */}
      <div style={{ flex:1, display:'flex', alignItems:'center', justifyContent:'center', padding:32 }}>
        <div style={{ maxWidth:560, width:'100%' }}>
          <div
            onClick={() => !loading && ref.current?.click()}
            onDragOver={e=>{e.preventDefault();setDrag(true);}}
            onDragLeave={()=>setDrag(false)}
            onDrop={e=>{e.preventDefault();setDrag(false);pick(e.dataTransfer.files);}}
            style={{
              background: drag ? 'rgba(59,130,246,0.08)' : 'rgba(255,255,255,0.04)',
              backdropFilter: 'blur(20px)',
              border: `1.5px dashed ${drag ? C.blue2 : 'rgba(255,255,255,0.15)'}`,
              borderRadius: 20, padding:'52px 40px', textAlign:'center',
              cursor: loading ? 'not-allowed' : 'pointer',
              transition:'all .25s',
              boxShadow: drag ? `0 0 48px ${C.blue}20` : 'none',
            }}
          >
            {/* Icon */}
            <div style={{ width:80, height:80, borderRadius:'50%', background:`linear-gradient(135deg,${C.blue}18,${C.purple}18)`, border:`1.5px solid rgba(59,130,246,0.3)`, display:'flex', alignItems:'center', justifyContent:'center', margin:'0 auto 22px', position:'relative' }}>
              <div style={{ position:'absolute', inset:-8, borderRadius:'50%', border:`1px dashed rgba(59,130,246,0.2)`, animation:'spin 18s linear infinite' }} />
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke={C.blue2} strokeWidth="1.8"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
            </div>

            <h1 style={{ fontSize:22, fontWeight:700, marginBottom:8, color:C.text }}>Upload Session Log Files</h1>
            <p style={{ fontSize:13, color:C.text2, lineHeight:1.7, marginBottom:24 }}>
              Select up to <strong style={{ color:C.blue2 }}>5 CSV files</strong> (one per day).<br/>
              All KPIs computed with <strong style={{ color:C.green2 }}>COUNT(DISTINCT SessionId)</strong>.
            </p>

            <button onClick={e=>{e.stopPropagation();ref.current?.click();}} disabled={loading}
              style={{ display:'inline-flex', alignItems:'center', gap:8, background:`linear-gradient(135deg,${C.blue},${C.purple})`, color:'white', border:'none', borderRadius:10, padding:'12px 28px', fontSize:13, fontWeight:700, cursor:'pointer', boxShadow:`0 4px 20px ${C.blue}44`, opacity:loading?.6:1 }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
              {files.length > 0 ? `${files.length} file${files.length>1?'s':''} selected` : 'Choose Files (up to 5)'}
            </button>
            <input ref={ref} type="file" multiple accept=".csv,.xlsx,.xls" style={{ display:'none' }} onChange={e=>pick(e.target.files)} />

            <div style={{ marginTop:16, display:'flex', alignItems:'center', justifyContent:'center', gap:6, fontSize:11, color:C.text3 }}>
              {['.csv','.xlsx','.xls'].map(f=><span key={f} style={{ background:'rgba(255,255,255,0.06)', border:`1px solid rgba(255,255,255,0.1)`, borderRadius:4, padding:'2px 8px', fontFamily:'monospace', color:C.text2 }}>{f}</span>)}
            </div>

            {/* Tip */}
            <div style={{ marginTop:18, background:'rgba(139,92,246,0.08)', border:`1px solid rgba(139,92,246,0.2)`, borderRadius:10, padding:'12px 16px', textAlign:'left' }}>
              <div style={{ fontSize:11, fontWeight:600, color:C.purple2, marginBottom:5 }}>💡 Excel not working? Save as CSV first:</div>
              <div style={{ fontSize:11, color:C.text2, lineHeight:1.8 }}>Excel → <strong style={{ color:C.text }}>File → Save As → CSV UTF-8 (.csv)</strong></div>
            </div>

            {/* Progress */}
            {loading && (
              <div style={{ marginTop:20 }}>
                <div style={{ display:'flex', justifyContent:'space-between', marginBottom:6 }}>
                  <span style={{ fontSize:11, color:C.text2, fontFamily:'monospace' }}>{progMsg}</span>
                  <span style={{ fontSize:11, color:C.blue2, fontFamily:'monospace', fontWeight:700 }}>{prog}%</span>
                </div>
                <div style={{ height:4, background:'rgba(255,255,255,0.08)', borderRadius:2, overflow:'hidden' }}>
                  <div style={{ height:'100%', width:prog+'%', background:`linear-gradient(90deg,${C.blue},${C.purple})`, transition:'width .3s', boxShadow:`0 0 10px ${C.blue}` }} />
                </div>
              </div>
            )}
          </div>

          {/* Selected files list */}
          {files.length > 0 && !loading && (
            <div style={{ marginTop:14, background:'rgba(255,255,255,0.04)', backdropFilter:'blur(20px)', border:`1px solid rgba(255,255,255,0.1)`, borderRadius:14, overflow:'hidden' }}>
              <div style={{ padding:'10px 16px', borderBottom:`1px solid rgba(255,255,255,0.07)`, display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                <span style={{ fontSize:11, fontWeight:600, color:C.text3, textTransform:'uppercase', letterSpacing:'.5px' }}>{files.length} file{files.length>1?'s':''} ready</span>
                <button onClick={()=>setFiles([])} style={{ fontSize:10, color:C.rose, background:'none', border:'none', cursor:'pointer' }}>✕ Clear</button>
              </div>
              {files.map((f,i)=>(
                <div key={i} style={{ display:'flex', alignItems:'center', gap:10, padding:'10px 16px', borderBottom: i<files.length-1?`1px solid rgba(255,255,255,0.06)`:'none' }}>
                  <div style={{ width:28, height:28, borderRadius:6, background:`${C.green2}14`, border:`1px solid ${C.green2}25`, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke={C.green2} strokeWidth="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                  </div>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ fontSize:12, color:C.text, fontWeight:500, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{f.name}</div>
                    <div style={{ fontSize:10, color:C.text3 }}>{fmtSize(f.size)}</div>
                  </div>
                  <span style={{ fontSize:9, background:`${C.blue}14`, color:C.blue2, border:`1px solid ${C.blue}25`, borderRadius:4, padding:'2px 7px', fontFamily:'monospace', fontWeight:600, flexShrink:0 }}>Day {i+1}</span>
                </div>
              ))}

              <div style={{ padding:'12px 16px' }}>
                <button onClick={handleUpload} style={{ width:'100%', background:`linear-gradient(135deg,${C.green},${C.cyan})`, color:'#07091a', border:'none', borderRadius:9, padding:12, fontSize:13, fontWeight:700, cursor:'pointer', boxShadow:`0 4px 20px ${C.green}44` }}>
                  Process & Calculate KPIs →
                </button>
              </div>
            </div>
          )}

          {error && <div style={{ marginTop:14, background:`${C.rose}10`, border:`1px solid ${C.rose}30`, borderRadius:9, padding:'10px 14px', color:C.rose, fontSize:12, fontFamily:'monospace' }}>⚠ {error}</div>}
        </div>
      </div>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );
}
