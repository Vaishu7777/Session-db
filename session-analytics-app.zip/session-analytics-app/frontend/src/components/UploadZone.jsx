import { useState, useRef } from 'react';
import { C } from '../styles/theme';
import { uploadFiles } from '../api';

export default function UploadZone({ onUploaded }) {
  const [drag, setDrag]       = useState(false);
  const [files, setFiles]     = useState([]);
  const [uploading, setUpload] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError]     = useState('');
  const inputRef              = useRef();

  function handleSelect(selected) {
    const arr = Array.from(selected).filter(f => /\.(csv|xlsx|xls)$/i.test(f.name));
    if (!arr.length) { setError('Please select .csv, .xlsx or .xls files'); return; }
    if (arr.length > 5) { setError('Maximum 5 files allowed (one per day)'); return; }
    setFiles(arr);
    setError('');
  }

  async function handleUpload() {
    if (!files.length) return;
    setUpload(true); setProgress(0); setError('');
    try {
      const result = await uploadFiles(files, p => setProgress(p));
      onUploaded(result);
    } catch (e) {
      setError(e.response?.data?.error || e.message);
    } finally {
      setUpload(false);
    }
  }

  const totalSize = files.reduce((s, f) => s + f.size, 0);
  const fmtSize   = b => b > 1e6 ? (b / 1e6).toFixed(1) + ' MB' : (b / 1e3).toFixed(0) + ' KB';

  return (
    <div style={{ minHeight: '100vh', background: C.bg, display: 'flex', flexDirection: 'column' }}>
      {/* Topbar */}
      <header style={{ height: 56, background: 'rgba(13,0,24,.97)', borderBottom: `1px solid ${C.border2}`, display: 'flex', alignItems: 'center', padding: '0 28px', gap: 12 }}>
        <div style={{ width: 34, height: 34, borderRadius: 9, background: `linear-gradient(135deg,${C.pink},${C.purple})`, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: `0 0 20px ${C.pink}44` }}>
          <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>
        </div>
        <span style={{ fontSize: 15, fontWeight: 700, background: `linear-gradient(90deg,${C.pink2},${C.pink},${C.purple})`, WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
          Session Analytics Dashboard
        </span>
        <span style={{ fontSize: 11, color: C.text3, fontFamily: 'monospace', marginLeft: 4 }}>v2.0 · React + Express + SQLite</span>
      </header>

      {/* Main */}
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 32, background: `radial-gradient(ellipse 70% 40% at 30% 20%,${C.purple}09 0%,transparent 65%), ${C.bg}` }}>
        <div style={{ maxWidth: 580, width: '100%' }}>

          {/* Drop zone */}
          <div
            onClick={() => !uploading && inputRef.current?.click()}
            onDragOver={e => { e.preventDefault(); setDrag(true); }}
            onDragLeave={() => setDrag(false)}
            onDrop={e => { e.preventDefault(); setDrag(false); handleSelect(e.dataTransfer.files); }}
            style={{
              background: drag ? `rgba(244,114,182,.04)` : C.surface,
              border: `1.5px dashed ${drag ? C.pink : C.border2}`,
              borderRadius: 22, padding: '48px 40px', textAlign: 'center',
              cursor: uploading ? 'not-allowed' : 'pointer',
              transition: 'all .25s',
              boxShadow: drag ? `0 0 48px ${C.purple}18` : 'none',
            }}
          >
            {/* Icon */}
            <div style={{ width: 80, height: 80, borderRadius: '50%', background: `linear-gradient(135deg,${C.pink}1a,${C.purple}1a)`, border: `1.5px solid ${C.pink}30`, display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 22px', position: 'relative' }}>
              <div style={{ position: 'absolute', inset: -8, borderRadius: '50%', border: `1px dashed ${C.pink}18`, animation: 'spin 20s linear infinite' }} />
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke={C.pink} strokeWidth="1.8"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
            </div>

            <h1 style={{ fontSize: 22, fontWeight: 700, marginBottom: 8, background: `linear-gradient(135deg,${C.text},${C.pink2})`, WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
              Upload Session Log Files
            </h1>
            <p style={{ fontSize: 13, color: C.text2, lineHeight: 1.7, marginBottom: 6 }}>
              Select up to <strong style={{ color: C.pink }}>5 CSV files</strong> (one per day).<br/>
              All KPIs use <strong style={{ color: C.mint }}>COUNT(DISTINCT SessionId)</strong> automatically.
            </p>
            <p style={{ fontSize: 11, color: C.text3, marginBottom: 24 }}>
              Supports .csv · .xlsx · .xls · up to 500 MB per file
            </p>

            <button
              onClick={e => { e.stopPropagation(); inputRef.current?.click(); }}
              disabled={uploading}
              style={{ display: 'inline-flex', alignItems: 'center', gap: 8, background: `linear-gradient(135deg,${C.pink},${C.purple})`, color: C.bg, border: 'none', borderRadius: 10, padding: '11px 26px', fontSize: 13, fontWeight: 700, cursor: uploading ? 'not-allowed' : 'pointer', opacity: uploading ? .6 : 1, boxShadow: `0 4px 20px ${C.pink}44` }}
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
              {files.length > 0 ? `${files.length} file${files.length > 1 ? 's' : ''} selected` : 'Choose Files (up to 5)'}
            </button>
            <input ref={inputRef} type="file" multiple accept=".csv,.xlsx,.xls" style={{ display: 'none' }} onChange={e => handleSelect(e.target.files)} />

            {/* Tip */}
            <div style={{ marginTop: 20, background: `${C.purple}0c`, border: `1px solid ${C.purple}22`, borderRadius: 10, padding: '12px 16px', textAlign: 'left' }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: C.purple, marginBottom: 6 }}>💡 If Excel fails — save as CSV first:</div>
              <div style={{ fontSize: 11, color: C.text2, lineHeight: 1.8 }}>
                Excel → <strong style={{ color: C.pink2 }}>File → Save As → CSV UTF-8 (.csv)</strong>
              </div>
            </div>
          </div>

          {/* Selected files list */}
          {files.length > 0 && (
            <div style={{ marginTop: 16, background: C.surface, border: `1px solid ${C.border2}`, borderRadius: 12, overflow: 'hidden' }}>
              <div style={{ padding: '10px 16px', borderBottom: `1px solid ${C.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: 11, fontWeight: 600, color: C.text3, textTransform: 'uppercase', letterSpacing: '.6px' }}>{files.length} file{files.length > 1 ? 's' : ''} · {fmtSize(totalSize)}</span>
                <button onClick={() => setFiles([])} style={{ fontSize: 10, color: C.rose, background: 'none', border: 'none', cursor: 'pointer' }}>✕ Clear</button>
              </div>
              {files.map((f, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 16px', borderBottom: i < files.length - 1 ? `1px solid ${C.border}` : 'none' }}>
                  <div style={{ width: 28, height: 28, borderRadius: 6, background: `${C.mint}18`, border: `1px solid ${C.mint}30`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke={C.mint} strokeWidth="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 12, color: C.text, fontWeight: 500, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{f.name}</div>
                    <div style={{ fontSize: 10, color: C.text3 }}>{fmtSize(f.size)}</div>
                  </div>
                  <span style={{ fontSize: 9, background: `${C.mint}18`, color: C.mint, border: `1px solid ${C.mint}30`, borderRadius: 4, padding: '2px 7px', fontFamily: 'monospace', fontWeight: 600 }}>Day {i + 1}</span>
                </div>
              ))}
            </div>
          )}

          {/* Upload button */}
          {files.length > 0 && !uploading && (
            <button
              onClick={handleUpload}
              style={{ width: '100%', marginTop: 14, background: `linear-gradient(135deg,${C.mint},${C.cyan})`, color: '#06000d', border: 'none', borderRadius: 10, padding: '13px', fontSize: 14, fontWeight: 700, cursor: 'pointer', boxShadow: `0 4px 20px ${C.mint}40` }}
            >
              Process & Calculate KPIs →
            </button>
          )}

          {/* Progress */}
          {uploading && (
            <div style={{ marginTop: 16 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                <span style={{ fontSize: 11, color: C.text2, fontFamily: 'monospace' }}>Processing files & inserting to database…</span>
                <span style={{ fontSize: 11, color: C.pink, fontFamily: 'monospace', fontWeight: 600 }}>{progress}%</span>
              </div>
              <div style={{ height: 4, background: C.surface2, borderRadius: 2, overflow: 'hidden' }}>
                <div style={{ height: '100%', width: progress + '%', background: `linear-gradient(90deg,${C.pink},${C.purple})`, transition: 'width .3s' }} />
              </div>
              <p style={{ fontSize: 11, color: C.text3, marginTop: 8, textAlign: 'center' }}>
                Parsing CSV → Deriving HSCT → DISTINCT dedup → SQLite insert…
              </p>
            </div>
          )}

          {/* Error */}
          {error && (
            <div style={{ marginTop: 14, background: `${C.rose}10`, border: `1px solid ${C.rose}40`, borderRadius: 9, padding: '10px 14px', color: C.rose, fontSize: 12, fontFamily: 'monospace' }}>
              ⚠ {error}
            </div>
          )}
        </div>
      </div>

      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
