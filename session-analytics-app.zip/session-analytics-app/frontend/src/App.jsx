import { useState } from 'react';
import UploadZone  from './components/UploadZone';
import Dashboard   from './components/Dashboard';

export default function App() {
  const [uploadResult, setUploadResult] = useState(null);

  // Called ONLY after backend confirms data is stored in SQLite
  function handleUploaded(result) {
    setUploadResult(result);   // triggers Dashboard to load with batchId
  }

  function handleNewUpload() {
    setUploadResult(null);     // go back to upload screen
  }

  if (!uploadResult) {
    return <UploadZone onUploaded={handleUploaded} />;
  }

  // Dashboard only renders AFTER upload is complete and DB is populated
  return <Dashboard uploadResult={uploadResult} onNewUpload={handleNewUpload} />;
}
