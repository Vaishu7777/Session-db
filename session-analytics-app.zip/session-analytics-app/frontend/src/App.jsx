import { useState } from 'react';
import UploadZone from './components/UploadZone';
import Dashboard  from './components/Dashboard';

export default function App() {
  const [uploadResult, setUploadResult] = useState(null);

  function handleUploaded(result) {
    setUploadResult(result);
  }

  function handleNewUpload() {
    setUploadResult(null);
  }

  if (!uploadResult) {
    return <UploadZone onUploaded={handleUploaded} />;
  }

  return <Dashboard uploadResult={uploadResult} onNewUpload={handleNewUpload} />;
}
