# Session Analytics Dashboard
> React + Express + SQLite — Production-ready KPI Dashboard

## Folder Structure
```
session-analytics-app/
├── backend/
│   ├── server.js              # Express entry point
│   ├── db.js                  # SQLite connection
│   ├── package.json
│   ├── routes/
│   │   ├── upload.js          # POST /api/upload (up to 5 files)
│   │   ├── kpis.js            # GET  /api/kpis/*
│   │   └── export.js          # GET  /api/export/excel
│   └── utils/
│       ├── parser.js          # CSV/Excel parser + column detection
│       └── compute.js         # All SQL KPI queries
├── frontend/
│   ├── index.html
│   ├── vite.config.js
│   ├── package.json
│   └── src/
│       ├── main.jsx
│       ├── App.jsx
│       ├── api.js
│       ├── styles/theme.js
│       └── components/
│           ├── UploadZone.jsx
│           ├── FilterBar.jsx
│           ├── KPICard.jsx
│           ├── KPITable.jsx
│           ├── Charts.jsx
│           └── Dashboard.jsx
└── database/
    └── schema.sql
```

---

## Setup Instructions

### Step 1 — Install Backend
```bash
cd backend
npm install
```

### Step 2 — Install Frontend
```bash
cd ../frontend
npm install
```

### Step 3 — Run Backend
```bash
cd backend
npm run dev
# Server starts at http://localhost:4000
```

### Step 4 — Run Frontend (new terminal)
```bash
cd frontend
npm run dev
# App opens at http://localhost:5173
```

### Step 5 — Open in browser
```
http://localhost:5173
```

---

## How to Use

1. Open `http://localhost:5173`
2. Upload **1 to 5 CSV files** (one per day)
3. Dashboard renders automatically with all KPIs
4. Use filters: HSCT threshold, Login threshold, BuildVersion, Last X days
5. Click **Export Excel** to download results
6. Click **New Upload** to upload different files

---

## Formulas Implemented

| KPI | Formula |
|---|---|
| Plant Attachment Rate | `COUNT(DISTINCT SessionId WHERE PLANT) / COUNT(DISTINCT SessionId)` |
| % Total HSCT ≤ Xs | `COUNT(DISTINCT SessionId WHERE HSCT ≤ X) / COUNT(DISTINCT SessionId)` |
| % Plant HSCT ≤ Xs | `COUNT(DISTINCT SessionId WHERE PLANT AND HSCT ≤ X) / COUNT(DISTINCT Plant SessionId)` |
| % NP MQTT HSCT ≤ Xs | `COUNT(DISTINCT SessionId WHERE NON-PLANT AND MQTT_HSCT ≤ X) / COUNT(DISTINCT NP SessionId)` |
| % Login ≤ 1s | `COUNT(DISTINCT SessionId WHERE Login ≤ 1) / COUNT(DISTINCT SessionId with Login)` |

**Derived columns:**
- `HSCT = System_HomeScreenConstructionTime − SessionStartTime`
- `PlantVsNonPlantSession = IF FallbackStartTime IS NULL/blank/nan → PLANT ELSE NON-PLANT`

**Duplicate handling:** All KPIs use `COUNT(DISTINCT SessionId)` — duplicates removed on upload.

---

## API Reference

```
POST /api/upload              Upload 1-5 files (multipart/form-data, field: files)
GET  /api/kpis/summary        All KPI numbers
GET  /api/kpis/trend          Per-date trend data
GET  /api/kpis/fallback       Top 5 fallback causes
GET  /api/kpis/filters        Available filter values
GET  /api/kpis/batches        All upload sessions
GET  /api/export/excel        Download Excel report
DELETE /api/upload/:batchId   Delete an upload batch
```

Query params for KPI endpoints:
```
batch          string   Upload batch ID
buildVersions  string   Comma-separated list
lccRevisions   string   Comma-separated list
fromDate       string   YYYY-MM-DD
toDate         string   YYYY-MM-DD
hsctEnd        number   Default: 5
loginThr       number   Default: 1
lastDays       number   Default: 0 (all)
```

---

## Required CSV Columns (10)

| Column | Usage |
|---|---|
| `SessionId` | DISTINCT deduplication |
| `BuildVersion` | Filter |
| `Lcc_Control_Software_Revision` | Filter |
| `SessionStartTime` | HSCT derivation |
| `System_HomeScreenConstructionTime` | HSCT derivation |
| `FallbackStartTime` | Plant/Non-Plant classification |
| `FallbackCause` | Fallback trend (Top 5) |
| `date` | Trend grouping |
| `AuthLoginTime_formatted` | Login KPI |
| `MQTT_Time_to_Construct_Home_Screen` | Non-Plant HSCT |

> Column names are auto-detected — variations in casing/spacing are handled automatically.
