const express    = require('express');
const cors       = require('cors');
const path       = require('path');
const { getDb }  = require('./db');

// Initialise DB on startup
getDb();

const app = express();
app.use(cors({ origin: ['http://localhost:5500', 'http://localhost:5500'] }));
app.use(express.json({ limit: '10mb' }));

// ── Routes ───────────────────────────────────────────────────────
app.use('/api/upload', require('./routes/upload'));
app.use('/api/kpis',   require('./routes/kpis'));
app.use('/api/export', require('./routes/export'));

// Health check
app.get('/api/health', (_, res) => res.json({ status: 'ok', time: new Date().toISOString() }));

// ── Start ────────────────────────────────────────────────────────
const PORT = process.env.PORT || 4100;
app.listen(PORT, () => {
  console.log(`\n✅  Session Analytics API running on http://localhost:${PORT}`);
  console.log(`    Upload:  POST /api/upload`);
  console.log(`    KPIs:    GET  /api/kpis/summary`);
  console.log(`    Trend:   GET  /api/kpis/trend`);
  console.log(`    Export:  GET  /api/export/excel\n`);
});
