const { parseSync } = require('csv-parse/sync');
const XLSX          = require('xlsx');
const path          = require('path');

// ── Column name normaliser ────────────────────────────────────────
function norm(s) { return s.toLowerCase().replace(/[\s_\-.]/g, ''); }

function findCol(keys, candidates) {
  for (const c of candidates) {
    const n   = norm(c);
    const hit = keys.find(k => norm(k) === n);
    if (hit) return hit;
  }
  for (const c of candidates) {
    const n   = norm(c);
    const hit = keys.find(k => norm(k).includes(n) || n.includes(norm(k)));
    if (hit) return hit;
  }
  return null;
}

// ── Detect all required columns ───────────────────────────────────
function detectCols(keys) {
  return {
    sessionId   : findCol(keys, ['SessionId', 'sessionid', 'session_id']),
    buildVersion: findCol(keys, ['BuildVersion', 'buildversion', 'Build_Version']),
    lccRevision : findCol(keys, ['Lcc_Control_Software_Revision', 'LccControlSoftwareRevision', 'lcc_control_software_revision']),
    startTime   : findCol(keys, ['SessionStartTime', 'sessionstarttime', 'session_start_time']),
    hsctRaw     : findCol(keys, ['System_HomeScreenConstructionTime', 'System_HomeScre', 'HomeScreenConstructionTime', 'SystemHomeScreenConstructionTime']),
    fallback    : findCol(keys, ['FallbackStartTime', 'fallbackstarttime', 'fallback_start_time']),
    fallbackCause: findCol(keys, ['FallbackCause', 'fallbackcause', 'fallback_cause']),
    date        : findCol(keys, ['date', 'Date', 'DATE', 'session_date']),
    loginTime   : findCol(keys, ['AuthLoginTime_formatted', 'AuthLoginTime', 'authlogintime', 'AuthLoginTime_fo', 'auth_login_time']),
    mqttHsct    : findCol(keys, ['MQTT_Time_to_Construct_Home_Screen', 'MQTTTimeToConstructHomeScreen', 'mqtt_time_to_construct_home_screen', 'MQTT_HSCT']),
  };
}

// ── Data helpers ──────────────────────────────────────────────────
function toNum(v) {
  if (v === null || v === undefined) return null;
  if (typeof v === 'number') return isNaN(v) ? null : v;
  if (typeof v === 'string') {
    const s = v.trim().replace(/,/g, '');
    if (!s) return null;
    if (['nan','null','none','nat','n/a','na','undefined','-','#n/a'].includes(s.toLowerCase())) return null;
    const n = parseFloat(s);
    return isNaN(n) ? null : n;
  }
  return null;
}

function isMissing(v) {
  if (v === null || v === undefined) return true;
  return ['', 'nan', 'none', 'nat', 'null', 'n/a', 'na', 'undefined', '-', '#n/a'].includes(String(v).trim().toLowerCase());
}

function toDateStr(v) {
  if (!v) return null;
  if (typeof v === 'number' && v > 40000 && v < 60000) {
    return new Date(Math.round((v - 25569) * 86400000)).toISOString().slice(0, 10);
  }
  const s = String(v).trim();
  if (!s) return null;
  const m = s.match(/(\d{4}-\d{2}-\d{2})/);
  if (m) return m[1];
  const d = new Date(s);
  return isNaN(d) ? s.slice(0, 10) : d.toISOString().slice(0, 10);
}

// ── Parse raw file buffer → array of row objects ──────────────────
function parseFile(buffer, originalname) {
  const ext = path.extname(originalname).toLowerCase();

  if (ext === '.csv') {
    const text = buffer.toString('utf-8');
    return parseSync(text, {
      columns           : true,
      skip_empty_lines  : true,
      trim              : true,
      relax_quotes      : true,
      relax_column_count: true,
    });
  }

  // Excel
  const wb  = XLSX.read(buffer, { type: 'buffer', cellDates: false, raw: true });
  const ws  = wb.Sheets[wb.SheetNames[0]];
  const aoa = XLSX.utils.sheet_to_json(ws, { header: 1, defval: null, raw: true });
  if (aoa.length < 2) return [];

  const headers = aoa[0].map(h => (h == null ? '' : String(h).trim()));
  return aoa.slice(1)
    .map(row => {
      const obj = {};
      headers.forEach((h, i) => { if (h) obj[h] = row[i] ?? null; });
      return obj;
    })
    .filter(o => Object.values(o).some(v => v !== null));
}

// ── Transform raw rows → DB-ready enriched rows ───────────────────
function enrichRows(rawRows, cm, fileName) {
  return rawRows.map(r => {
    const sid = cm.sessionId ? String(r[cm.sessionId] ?? '').trim() : null;

    // Derived 1: HSCT = System_HomeScreen - SessionStart (seconds)
    let hsct = null;
    const raw = toNum(r[cm.hsctRaw]);
    const st  = toNum(r[cm.startTime]);
    if (raw !== null && st !== null) {
      let diff = raw - st;
      if (Math.abs(diff) > 86400) diff /= 1000; // ms → s
      hsct = diff;
    }

    // Derived 2: PlantVsNonPlantSession
    const fbVal   = cm.fallback ? r[cm.fallback] : null;
    const isPlant = isMissing(fbVal);
    const plantFlag = isPlant ? 'PLANT' : 'NON-PLANT';

    // MQTT HSCT (used for Non-Plant rate)
    let mqttHsct = toNum(r[cm.mqttHsct]);
    if (mqttHsct !== null && mqttHsct > 1000) mqttHsct /= 1000;

    // Auth login time (already seconds)
    let loginTime = toNum(r[cm.loginTime]);
    if (loginTime !== null && loginTime > 1000) loginTime /= 1000;

    // FallbackCause (exclude nan)
    const fcRaw     = cm.fallbackCause ? r[cm.fallbackCause] : null;
    const fbCause   = isMissing(fcRaw) ? null : String(fcRaw).trim();

    const dateStr   = cm.date ? toDateStr(r[cm.date]) : null;
    const bv        = cm.buildVersion  ? String(r[cm.buildVersion]  ?? '').trim() || null : null;
    const lcc       = cm.lccRevision   ? String(r[cm.lccRevision]   ?? '').trim() || null : null;

    return {
      session_id         : sid,
      build_version      : bv,
      lcc_revision       : lcc,
      session_start_time : st,
      hsct,
      fallback_start_time: cm.fallback ? String(r[cm.fallback] ?? '').trim() || null : null,
      fallback_cause     : fbCause,
      date               : dateStr,
      auth_login_time    : loginTime,
      mqtt_hsct          : mqttHsct,
      plant_flag         : plantFlag,
      file_name          : fileName,
    };
  });
}

module.exports = { parseFile, enrichRows, detectCols };
