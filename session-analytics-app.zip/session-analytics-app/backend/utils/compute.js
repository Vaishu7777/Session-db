// ================================================================
// KPI Computation Engine — Session Analytics Dashboard
// All 18 KPIs use COUNT(DISTINCT SessionId) per spec
// Formulas verified against Arranged_KPI_Document
// ================================================================

const { getDb } = require('../db');

// ── Build WHERE clause from filters ──────────────────────────────
function buildWhere(params) {
  const { batch, buildVersions = [], lccRevisions = [], fromDate, toDate, lastDays = 0 } = params;
  const conditions = [], args = {};

  if (batch) { conditions.push('upload_batch = :batch'); args.batch = batch; }

  if (buildVersions.length) {
    const ph = buildVersions.map((_, i) => `:bv${i}`).join(',');
    conditions.push(`build_version IN (${ph})`);
    buildVersions.forEach((v, i) => { args[`bv${i}`] = v; });
  }
  if (lccRevisions.length) {
    const ph = lccRevisions.map((_, i) => `:lcc${i}`).join(',');
    conditions.push(`lcc_revision IN (${ph})`);
    lccRevisions.forEach((v, i) => { args[`lcc${i}`] = v; });
  }
  if (fromDate) { conditions.push('date >= :fromDate'); args.fromDate = fromDate; }
  if (toDate)   { conditions.push('date <= :toDate');   args.toDate   = toDate;   }

  // KPI 6/7: Last X days filter
  if (lastDays > 0) {
    const d = new Date();
    d.setDate(d.getDate() - lastDays);
    conditions.push('date >= :lastCutoff');
    args.lastCutoff = d.toISOString().slice(0, 10);
  }

  return {
    where: conditions.length ? `WHERE ${conditions.join(' AND ')}` : '',
    args
  };
}

// ── KPI Summary — all 18 KPIs in one SQL pass ───────────────────
// Formulas:
// KPI 1  : Plant Attachment Rate = COUNT(DISTINCT WHERE PLANT) / COUNT(DISTINCT total)
// KPI 2  : % Total HSCT BETWEEN start AND end = COUNT(DISTINCT WHERE HSCT in range) / COUNT(DISTINCT total)
// KPI 3  : % Plant HSCT = COUNT(DISTINCT WHERE PLANT AND HSCT in range) / COUNT(DISTINCT WHERE PLANT)
// KPI 4  : Login Success = COUNT(DISTINCT WHERE Login<=thr) / COUNT(DISTINCT WHERE Login IS NOT NULL)
// KPI 5  : % Non-Plant MQTT HSCT = COUNT(DISTINCT WHERE NON-PLANT AND MQTT_HSCT in range) / COUNT(DISTINCT WHERE NON-PLANT)
// KPI 6  : % HSCT Last N Days (filtered by lastDays in WHERE clause above)
// KPI 7  : Total Sessions = COUNT(DISTINCT total)  [after lastDays filter]
// KPI 8  : Plant % = Plant / Total
// KPI 9  : Non-Plant % = Non-Plant / Total
// KPI 10 : Total Plant Sessions = COUNT(DISTINCT WHERE PLANT)
// KPI 11 : Total Non-Plant Sessions = COUNT(DISTINCT WHERE NON-PLANT)
// KPI 12 : HSCT Sessions Count = COUNT(DISTINCT WHERE HSCT in range)
// KPI 13 : Plant % Within HSCT = COUNT(DISTINCT PLANT & HSCT) / COUNT(DISTINCT PLANT)
// KPI 14 : Non-Plant % MQTT HSCT = COUNT(DISTINCT NP & MQTT) / COUNT(DISTINCT NP)
// KPI 15 : Total Plant HSCT Sessions = COUNT(DISTINCT WHERE PLANT AND HSCT in range)
// KPI 16 : Total NP HSCT Sessions = COUNT(DISTINCT WHERE NON-PLANT AND MQTT_HSCT in range)
// KPI 17 : Fallback Trend Top 5 (separate query)
// KPI 18 : Total Sessions Trend (separate query, grouped by date)

function computeKPIs(params) {
  const db = getDb();
  const { where, args } = buildWhere(params);
  const { hsctStart = 0, hsctEnd = 5, loginThr = 1 } = params;

  const hs = +hsctStart, he = +hsctEnd, lt = +loginThr;

  const sql = `
    SELECT
      -- KPI 7: Total DISTINCT sessions (also used as denominator for KPI 1,2,8,9)
      COUNT(DISTINCT session_id) AS total,

      -- KPI 10: Total Plant Sessions
      COUNT(DISTINCT CASE WHEN plant_flag = 'PLANT'     THEN session_id END) AS plant_count,

      -- KPI 11: Total Non-Plant Sessions
      COUNT(DISTINCT CASE WHEN plant_flag = 'NON-PLANT' THEN session_id END) AS nonplant_count,

      -- KPI 12/2: Sessions where HSCT BETWEEN hsctStart AND hsctEnd
      COUNT(DISTINCT CASE
        WHEN hsct >= ${hs} AND hsct <= ${he}
        THEN session_id END) AS hsct_total,

      -- KPI 15/3: Plant sessions where HSCT BETWEEN start AND end (uses derived HSCT)
      COUNT(DISTINCT CASE
        WHEN plant_flag = 'PLANT'
          AND hsct >= ${hs} AND hsct <= ${he}
        THEN session_id END) AS plant_hsct,

      -- KPI 16/5: Non-Plant sessions where MQTT_HSCT BETWEEN start AND end
      COUNT(DISTINCT CASE
        WHEN plant_flag = 'NON-PLANT'
          AND mqtt_hsct >= ${hs} AND mqtt_hsct <= ${he}
        THEN session_id END) AS nonplant_hsct,

      -- KPI 4 numerator: Sessions where LoginTime BETWEEN 0 AND threshold
      COUNT(DISTINCT CASE
        WHEN auth_login_time >= 0 AND auth_login_time <= ${lt}
        THEN session_id END) AS login_ok,

      -- KPI 4 denominator: Sessions where LoginTime IS NOT NULL
      COUNT(DISTINCT CASE
        WHEN auth_login_time IS NOT NULL
        THEN session_id END) AS login_total

    FROM sessions ${where}
  `;

  const r   = db.prepare(sql).get(args);
  const pct = (a, b) => b > 0 ? Math.round((a / b) * 10000) / 100 : 0;

  const T  = r.total          || 0;  // KPI 7
  const P  = r.plant_count    || 0;  // KPI 10
  const NP = r.nonplant_count || 0;  // KPI 11

  return {
    // Core counts
    totalSessions      : T,           // KPI 7
    plantSessions      : P,           // KPI 10
    nonPlantSessions   : NP,          // KPI 11

    // KPI 1 / 8: Plant Attachment Rate = Plant / Total
    plantAttachRate    : pct(P, T),
    plantRate          : pct(P, T),   // KPI 8

    // KPI 9: Non-Plant % = Non-Plant / Total
    nonPlantRate       : pct(NP, T),

    // KPI 2 / 6: % Total HSCT BETWEEN start AND end / Total
    hsctRate           : pct(r.hsct_total, T),
    hsctCount          : r.hsct_total    || 0,   // KPI 12

    // KPI 3 / 13: % Plant HSCT / Total Plant
    plantHsctRate      : pct(r.plant_hsct, P),
    plantHsctCount     : r.plant_hsct   || 0,   // KPI 15

    // KPI 5 / 14: % Non-Plant MQTT HSCT / Total Non-Plant
    nonPlantHsctRate   : pct(r.nonplant_hsct, NP),
    nonPlantHsctCount  : r.nonplant_hsct || 0,  // KPI 16

    // KPI 4: Login Success = Login<=thr / Sessions with Login
    loginRate          : pct(r.login_ok, r.login_total),
    loginCount         : r.login_ok    || 0,
    loginTotal         : r.login_total || 0,

    // Config echoed back for UI
    hsctStart, hsctEnd, loginThr,
  };
}

// ── KPI 18: Total Sessions Trend (per date) ───────────────────────
function getTrend(params) {
  const db = getDb();
  const { where, args } = buildWhere(params);
  const { hsctStart = 0, hsctEnd = 5, loginThr = 1 } = params;
  const hs = +hsctStart, he = +hsctEnd, lt = +loginThr;

  const sql = `
    SELECT
      date,
      COUNT(DISTINCT session_id)                                AS total,
      COUNT(DISTINCT CASE WHEN plant_flag='PLANT'     THEN session_id END) AS plant,
      COUNT(DISTINCT CASE WHEN plant_flag='NON-PLANT' THEN session_id END) AS non_plant,
      COUNT(DISTINCT CASE WHEN hsct >= ${hs} AND hsct <= ${he} THEN session_id END) AS hsct_ok,
      COUNT(DISTINCT CASE WHEN plant_flag='PLANT'     AND hsct     >= ${hs} AND hsct     <= ${he} THEN session_id END) AS plant_hsct,
      COUNT(DISTINCT CASE WHEN plant_flag='NON-PLANT' AND mqtt_hsct >= ${hs} AND mqtt_hsct <= ${he} THEN session_id END) AS np_hsct,
      COUNT(DISTINCT CASE WHEN auth_login_time >= 0 AND auth_login_time <= ${lt} THEN session_id END) AS login_ok,
      COUNT(DISTINCT CASE WHEN auth_login_time IS NOT NULL THEN session_id END) AS login_total
    FROM sessions ${where}
    GROUP BY date
    ORDER BY date ASC
  `;

  const pct = (a, b) => b > 0 ? Math.round((a / b) * 10000) / 100 : 0;
  return db.prepare(sql).all(args).map(r => ({
    date          : r.date,
    total         : r.total,
    plant         : r.plant,
    nonPlant      : r.non_plant,
    plantRate     : pct(r.plant,      r.total),
    hsctRate      : pct(r.hsct_ok,    r.total),
    plantHsctRate : pct(r.plant_hsct, r.plant),
    npHsctRate    : pct(r.np_hsct,    r.non_plant),
    loginRate     : pct(r.login_ok,   r.login_total),
  }));
}

// ── KPI 17: Fallback Trend Top 5 (excl. nan) ─────────────────────
function getFallbackTrend(params) {
  const db = getDb();
  const { where, args } = buildWhere(params);
  const andWhere = where ? where + ' AND' : 'WHERE';

  const sql = `
    SELECT fallback_cause AS cause, COUNT(DISTINCT session_id) AS total
    FROM sessions
    ${andWhere} fallback_cause IS NOT NULL
      AND LOWER(TRIM(fallback_cause)) NOT IN ('nan','none','null','')
    GROUP BY fallback_cause
    ORDER BY total DESC
    LIMIT 5
  `;
  return db.prepare(sql).all(args);
}

// ── HSCT Distribution (for bar chart) ────────────────────────────
function getHsctDistribution(params) {
  const db = getDb();
  const { where, args } = buildWhere(params);
  const andWhere = where ? where + ' AND' : 'WHERE';

  const sql = `
    SELECT
      CASE
        WHEN hsct >= 0  AND hsct <= 1  THEN '0-1s'
        WHEN hsct >  1  AND hsct <= 3  THEN '1-3s'
        WHEN hsct >  3  AND hsct <= 5  THEN '3-5s'
        WHEN hsct >  5  AND hsct <= 8  THEN '5-8s'
        WHEN hsct >  8  AND hsct <= 12 THEN '8-12s'
        WHEN hsct >  12 AND hsct <= 20 THEN '12-20s'
        WHEN hsct >  20                THEN '>20s'
      END AS bucket,
      COUNT(DISTINCT session_id) AS count
    FROM sessions
    ${andWhere} hsct IS NOT NULL AND hsct >= 0
    GROUP BY bucket
    ORDER BY MIN(hsct)
  `;
  return db.prepare(sql).all(args).filter(r => r.bucket);
}

// ── Filter options ────────────────────────────────────────────────
function getFilterOptions(batch) {
  const db = getDb();
  const w  = batch ? 'WHERE upload_batch = ?' : '';
  const a  = batch ? [batch] : [];
  return {
    buildVersions: db.prepare(`SELECT DISTINCT build_version FROM sessions ${w} WHERE build_version IS NOT NULL ORDER BY build_version`).all(...a).map(r => r.build_version),
    lccRevisions : db.prepare(`SELECT DISTINCT lcc_revision  FROM sessions ${w} WHERE lcc_revision  IS NOT NULL ORDER BY lcc_revision`).all(...a).map(r => r.lcc_revision),
    dates        : db.prepare(`SELECT DISTINCT date          FROM sessions ${w} WHERE date          IS NOT NULL ORDER BY date`).all(...a).map(r => r.date),
  };
}

function getBatches() {
  return getDb().prepare('SELECT * FROM upload_batches ORDER BY created_at DESC').all();
}

module.exports = { computeKPIs, getTrend, getFallbackTrend, getHsctDistribution, getFilterOptions, getBatches };
