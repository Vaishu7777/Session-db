// ================================================================
// KPI Computation Engine
// All formulas per corrected final spec (Images 1-3)
// ALL use COUNT(DISTINCT SessionId)
// ================================================================

const { getDb } = require('../db');

// ── Build WHERE clause ────────────────────────────────────────────
function buildWhere(params) {
  const { batch, buildVersions = [], lccRevisions = [], fromDate, toDate, lastDays = 0 } = params;
  const conditions = [];
  const args = {};

  if (batch) { conditions.push('upload_batch = :batch'); args.batch = batch; }

  if (buildVersions.length) {
    const ph = buildVersions.map((_, i) => `:bv${i}`).join(',');
    conditions.push(`build_version IN (${ph})`);
    buildVersions.forEach((v, i) => { args[`bv${i}`] = v; });
  }

  if (lccRevisions.length) {
    const ph = lccRevisions.map((_, i) => `:lcc${i}`).join(',');
    conditions.push(`lcc_revision IN (${ph})`);
    lccRevisions.forEach((v, i) => { args[`lcc${i}`] = v; });
  }

  if (fromDate) { conditions.push('date >= :fromDate'); args.fromDate = fromDate; }
  if (toDate)   { conditions.push('date <= :toDate');   args.toDate   = toDate;   }

  // Last X days filter
  if (lastDays > 0) {
    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - lastDays);
    const cutStr = cutoff.toISOString().slice(0, 10);
    conditions.push('date >= :lastDaysCutoff');
    args.lastDaysCutoff = cutStr;
  }

  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
  return { where, args };
}

// ── Main KPI query — all formulas in one pass ─────────────────────
function computeKPIs(params) {
  const db = getDb();
  const { where, args } = buildWhere(params);
  const {
    hsctStart = 0,
    hsctEnd   = 5,
    loginThr  = 1,
    lastDays  = 0,
  } = params;

  // ── Formula 1: Plant Attachment Rate
  //    COUNT(DISTINCT SessionId WHERE Plant='PLANT') / COUNT(DISTINCT SessionId)
  //
  // ── Formula 2: % Sessions HSCT ≤ X
  //    COUNT(DISTINCT SessionId WHERE HSCT BETWEEN Start AND End) / COUNT(DISTINCT SessionId)
  //
  // ── Formula 3: % Plant HSCT ≤ X
  //    COUNT(DISTINCT SessionId WHERE Plant='PLANT' AND HSCT IN RANGE) / COUNT(DISTINCT SessionId WHERE Plant='PLANT')
  //
  // ── Formula 4: % Non-Plant HSCT ≤ X
  //    COUNT(DISTINCT SessionId WHERE Plant='NON-PLANT' AND HSCT IN RANGE) / COUNT(DISTINCT SessionId WHERE Plant='NON-PLANT')
  //
  // ── Formula 5: % Login ≤ X
  //    COUNT(DISTINCT SessionId WHERE LoginTime BETWEEN 0 AND Threshold) / COUNT(DISTINCT SessionId WHERE LoginTime IS NOT NULL)
  //
  // ── Formula 6: KPI 1 Last X Days (already filtered in WHERE clause)
  //    COUNT(DISTINCT SessionId WHERE HSCT IN RANGE AND Date IN Last X Days) / COUNT(DISTINCT SessionId WHERE Date IN Last X Days)

  const sql = `
    SELECT
      -- Total DISTINCT sessions
      COUNT(DISTINCT session_id) AS total,

      -- Formula 1: Plant Attachment Rate numerator/denominator
      COUNT(DISTINCT CASE WHEN plant_flag = 'PLANT'     THEN session_id END) AS plant_count,
      COUNT(DISTINCT CASE WHEN plant_flag = 'NON-PLANT' THEN session_id END) AS nonplant_count,

      -- Formula 2: % Total HSCT BETWEEN hsctStart AND hsctEnd
      COUNT(DISTINCT CASE
        WHEN hsct >= ${+hsctStart} AND hsct <= ${+hsctEnd}
        THEN session_id END) AS hsct_ok,

      -- Formula 3: % Plant HSCT in range (numerator only — denom = plant_count)
      COUNT(DISTINCT CASE
        WHEN plant_flag = 'PLANT' AND hsct >= ${+hsctStart} AND hsct <= ${+hsctEnd}
        THEN session_id END) AS plant_hsct_ok,

      -- Formula 4: % Non-Plant HSCT in range (mqtt_hsct) — denom = nonplant_count
      COUNT(DISTINCT CASE
        WHEN plant_flag = 'NON-PLANT' AND mqtt_hsct >= ${+hsctStart} AND mqtt_hsct <= ${+hsctEnd}
        THEN session_id END) AS nonplant_hsct_ok,

      -- Formula 5 numerator: LoginTime BETWEEN 0 AND loginThr
      COUNT(DISTINCT CASE
        WHEN auth_login_time >= 0 AND auth_login_time <= ${+loginThr}
        THEN session_id END) AS login_ok,

      -- Formula 5 denominator: COUNT(DISTINCT SessionId WHERE LoginTime IS NOT NULL)
      -- Spec: Sessions Having Login Time = IS NOT NULL (no > 0 condition)
      COUNT(DISTINCT CASE
        WHEN auth_login_time IS NOT NULL
        THEN session_id END) AS login_total

    FROM sessions ${where}
  `;

  const r = db.prepare(sql).get(args);
  const pct = (a, b) => b > 0 ? Math.round((a / b) * 10000) / 100 : 0;

  const T  = r.total        || 0;
  const P  = r.plant_count  || 0;
  const NP = r.nonplant_count || 0;

  return {
    // Counts
    totalSessions      : T,
    plantSessions      : P,
    nonPlantSessions   : NP,

    // Formula 1: Plant Attachment Rate
    plantAttachRate    : pct(P, T),

    // Formula 2: % Total HSCT BETWEEN start AND end
    hsctRate           : pct(r.hsct_ok, T),
    hsctCount          : r.hsct_ok || 0,

    // Formula 3: % Plant HSCT
    plantHsctRate      : pct(r.plant_hsct_ok, P),
    plantHsctCount     : r.plant_hsct_ok || 0,

    // Formula 4: % Non-Plant MQTT HSCT
    nonPlantHsctRate   : pct(r.nonplant_hsct_ok, NP),
    nonPlantHsctCount  : r.nonplant_hsct_ok || 0,

    // Formula 5: % Login ≤ threshold
    loginRate          : pct(r.login_ok, r.login_total),
    loginCount         : r.login_ok    || 0,
    loginTotal         : r.login_total || 0,

    // KPI 2 distribution
    plantRate          : pct(P, T),
    nonPlantRate       : pct(NP, T),

    // Config
    hsctStart, hsctEnd, loginThr, lastDays,
  };
}

// ── Per-date trend ────────────────────────────────────────────────
function getTrend(params) {
  const db = getDb();
  const { where, args } = buildWhere(params);
  const { hsctStart = 0, hsctEnd = 5, loginThr = 1 } = params;

  const sql = `
    SELECT
      date,
      COUNT(DISTINCT session_id) AS total,
      COUNT(DISTINCT CASE WHEN plant_flag='PLANT'     THEN session_id END) AS plant,
      COUNT(DISTINCT CASE WHEN plant_flag='NON-PLANT' THEN session_id END) AS non_plant,
      COUNT(DISTINCT CASE WHEN hsct >= ${+hsctStart} AND hsct <= ${+hsctEnd} THEN session_id END) AS hsct_ok,
      COUNT(DISTINCT CASE WHEN plant_flag='PLANT' AND hsct >= ${+hsctStart} AND hsct <= ${+hsctEnd} THEN session_id END) AS plant_hsct_ok,
      COUNT(DISTINCT CASE WHEN plant_flag='NON-PLANT' AND mqtt_hsct >= ${+hsctStart} AND mqtt_hsct <= ${+hsctEnd} THEN session_id END) AS np_hsct_ok,
      COUNT(DISTINCT CASE WHEN auth_login_time >= 0 AND auth_login_time <= ${+loginThr} THEN session_id END) AS login_ok,
      COUNT(DISTINCT CASE WHEN auth_login_time IS NOT NULL                         THEN session_id END) AS login_total
    FROM sessions ${where}
    GROUP BY date
    ORDER BY date ASC
  `;

  const pct = (a, b) => b > 0 ? Math.round((a / b) * 10000) / 100 : 0;

  return db.prepare(sql).all(args).map(r => ({
    date           : r.date,
    total          : r.total,
    plant          : r.plant,
    nonPlant       : r.non_plant,
    plantRate      : pct(r.plant,         r.total),
    hsctRate       : pct(r.hsct_ok,       r.total),
    plantHsctRate  : pct(r.plant_hsct_ok, r.plant),
    npHsctRate     : pct(r.np_hsct_ok,    r.non_plant),
    loginRate      : pct(r.login_ok,      r.login_total),
  }));
}

// ── Fallback Top 5 (excl nan) ─────────────────────────────────────
function getFallbackTrend(params) {
  const db = getDb();
  const { where, args } = buildWhere(params);

  const andOrWhere = where ? where + ' AND' : 'WHERE';
  const sql = `
    SELECT fallback_cause, COUNT(DISTINCT session_id) AS cnt
    FROM sessions
    ${andOrWhere} fallback_cause IS NOT NULL AND fallback_cause != ''
    GROUP BY fallback_cause
    ORDER BY cnt DESC
    LIMIT 5
  `;

  return db.prepare(sql).all(args).map(r => ({
    cause: r.fallback_cause,
    total: r.cnt,
  }));
}

// ── Filter options ────────────────────────────────────────────────
function getFilterOptions(batch) {
  const db  = getDb();
  const w   = batch ? 'WHERE upload_batch = ?' : '';
  const a   = batch ? [batch] : [];
  return {
    buildVersions: db.prepare(`SELECT DISTINCT build_version FROM sessions ${w} WHERE build_version IS NOT NULL ORDER BY build_version`).all(...a).map(r => r.build_version),
    lccRevisions : db.prepare(`SELECT DISTINCT lcc_revision  FROM sessions ${w} WHERE lcc_revision  IS NOT NULL ORDER BY lcc_revision`).all(...a).map(r => r.lcc_revision),
    dates        : db.prepare(`SELECT DISTINCT date           FROM sessions ${w} WHERE date          IS NOT NULL ORDER BY date`).all(...a).map(r => r.date),
  };
}

function getBatches() {
  return getDb().prepare('SELECT * FROM upload_batches ORDER BY created_at DESC').all();
}

module.exports = { computeKPIs, getTrend, getFallbackTrend, getFilterOptions, getBatches };
