const Database = require('better-sqlite3');
const path     = require('path');
const fs       = require('fs');

const DB_PATH  = path.join(__dirname, '..', 'database', 'analytics.db');
const SCHEMA   = path.join(__dirname, '..', 'database', 'schema.sql');

let _db = null;

function getDb() {
  if (_db) return _db;

  // Ensure database directory exists
  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

  _db = new Database(DB_PATH);

  // ── Performance tuning for millions of rows ──────────────────
  _db.pragma('journal_mode = WAL');       // concurrent reads + writes
  _db.pragma('synchronous   = NORMAL');   // safe + fast (not FULL)
  _db.pragma('cache_size    = -131072');  // 128 MB page cache
  _db.pragma('temp_store    = MEMORY');   // temp tables in RAM
  _db.pragma('mmap_size     = 536870912');// 512 MB memory-mapped IO
  _db.pragma('page_size     = 4096');     // standard page size
  _db.pragma('auto_vacuum   = NONE');     // no auto vacuum during inserts

  // Apply schema
  const schema = fs.readFileSync(SCHEMA, 'utf8');
  _db.exec(schema);

  console.log('✅ SQLite ready:', DB_PATH);
  return _db;
}

module.exports = { getDb };
