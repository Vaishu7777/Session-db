const express  = require('express');
const multer   = require('multer');
const { v4: uuid } = require('uuid');
const { Readable } = require('stream');
const { parse }    = require('csv-parse');
const XLSX         = require('xlsx');
const { getDb }    = require('../db');
const { enrichRows, detectCols } = require('../utils/parser');

const router  = express.Router();
const upload  = multer({ storage: multer.memoryStorage(), limits: { fileSize: 500*1024*1024, files: 5 } });
const BATCH_SIZE = 5000;

// ── Stream CSV → enrich → dedup → insert ─────────────────────────
function processCSV(buffer, cm, fileName, batchId, insertMany) {
  return new Promise((resolve, reject) => {
    let rawCount = 0, insertedCount = 0, batch = [];
    const seen = new Set();

    const parser = parse({
      columns: true, skip_empty_lines: true, trim: true,
      relax_quotes: true, relax_column_count: true, bom: true,
    });

    parser.on('readable', () => {
      let record;
      while ((record = parser.read()) !== null) {
        rawCount++;
        const enriched = enrichRows([record], cm, fileName);
        if (!enriched.length) continue;
        const row = enriched[0];

        // DISTINCT dedup by SessionId
        const sid = row.session_id ? String(row.session_id).trim().toLowerCase() : null;
        if (sid && sid !== '' && !['null','nan','undefined'].includes(sid)) {
          if (seen.has(sid)) continue;  // skip duplicate
          seen.add(sid);
        }

        batch.push({ ...row, upload_batch: batchId });

        if (batch.length >= BATCH_SIZE) {
          insertMany(batch);
          insertedCount += batch.length;
          batch = [];
        }
      }
    });

    parser.on('end', () => {
      if (batch.length > 0) { insertMany(batch); insertedCount += batch.length; }
      resolve({ rawCount, insertedCount, distinctCount: seen.size });
    });

    parser.on('error', reject);

    const readable = new Readable();
    readable.push(buffer);
    readable.push(null);
    readable.pipe(parser);
  });
}

function processExcel(buffer, cm, fileName, batchId, insertMany) {
  const wb  = XLSX.read(buffer, { type: 'buffer', cellDates: false, raw: true });
  const ws  = wb.Sheets[wb.SheetNames[0]];
  const aoa = XLSX.utils.sheet_to_json(ws, { header: 1, defval: null, raw: true });
  if (aoa.length < 2) return { rawCount: 0, insertedCount: 0 };

  const headers = aoa[0].map(h => h == null ? '' : String(h).trim());
  const seen = new Set(); let rawCount = 0, insertedCount = 0, batch = [];

  for (let i = 1; i < aoa.length; i++) {
    const obj = {};
    headers.forEach((h, j) => { if (h) obj[h] = aoa[i][j] ?? null; });
    rawCount++;

    const enriched = enrichRows([obj], cm, fileName);
    if (!enriched.length) continue;
    const row = enriched[0];

    const sid = row.session_id ? String(row.session_id).trim().toLowerCase() : null;
    if (sid && sid !== '' && !['null','nan','undefined'].includes(sid)) {
      if (seen.has(sid)) continue;
      seen.add(sid);
    }

    batch.push({ ...row, upload_batch: batchId });
    if (batch.length >= BATCH_SIZE) { insertMany(batch); insertedCount += batch.length; batch = []; }
  }

  if (batch.length > 0) { insertMany(batch); insertedCount += batch.length; }
  return { rawCount, insertedCount };
}

// ── POST /api/upload ──────────────────────────────────────────────
// Step 1: Parse & store in SQLite
// Step 2: Return batchId so frontend can query KPIs
router.post('/', upload.array('files', 5), async (req, res) => {
  if (!req.files || req.files.length === 0)
    return res.status(400).json({ error: 'No files uploaded' });

  const db      = getDb();
  const batchId = uuid();
  let totalRaw  = 0, totalInserted = 0;
  const fileResults = [];

  try {
    // Prepare insert statement
    const stmt = db.prepare(`
      INSERT INTO sessions (
        session_id, build_version, lcc_revision, session_start_time,
        hsct, fallback_start_time, fallback_cause, date,
        auth_login_time, mqtt_hsct, plant_flag, file_name, upload_batch
      ) VALUES (
        @session_id, @build_version, @lcc_revision, @session_start_time,
        @hsct, @fallback_start_time, @fallback_cause, @date,
        @auth_login_time, @mqtt_hsct, @plant_flag, @file_name, @upload_batch
      )
    `);

    // Wrap inserts in transaction for speed
    const insertMany = db.transaction(rows => { for (const r of rows) stmt.run(r); });

    // ── STEP 1: Process each file → store in SQLite ───────────────
    for (const file of req.files) {
      const ext   = file.originalname.split('.').pop().toLowerCase();
      const isCSV = ext === 'csv';
      console.log(`\n📂 [Step 1] Storing: ${file.originalname} (${(file.size/1024/1024).toFixed(1)} MB)`);

      let cm, stats;

      if (isCSV) {
        // Detect columns from header line
        const header = file.buffer.toString('utf-8', 0, Math.min(4096, file.buffer.length)).split('\n')[0];
        const headers = header.split(',').map(h => h.trim().replace(/^["']|["']$/g,''));
        cm = detectCols(headers);
        console.log(`   Columns: SessionId=${cm.sessionId}, HSCT=${cm.hsctRaw}, Login=${cm.loginTime}, Plant=${cm.plantCol}`);
        stats = await processCSV(file.buffer, cm, file.originalname, batchId, insertMany);
      } else {
        const wb   = XLSX.read(file.buffer, { type:'buffer', raw:true });
        const hdrs = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { header:1, defval:null })[0]
                        ?.map(h => h==null?'':String(h).trim()) || [];
        cm    = detectCols(hdrs);
        stats = processExcel(file.buffer, cm, file.originalname, batchId, insertMany);
      }

      totalRaw      += stats.rawCount;
      totalInserted += stats.insertedCount;
      console.log(`   ✅ Stored: ${stats.rawCount.toLocaleString()} rows → ${stats.insertedCount.toLocaleString()} distinct in SQLite`);

      fileResults.push({
        file             : file.originalname,
        status           : 'ok',
        rawRows          : stats.rawCount,
        inserted         : stats.insertedCount,
        duplicatesRemoved: stats.rawCount - stats.insertedCount,
        detectedCols     : Object.entries(cm).map(([field, col]) => ({ field, col, found: !!col })),
      });
    }

    // ── STEP 2: Save batch metadata ───────────────────────────────
    db.prepare(`
      INSERT INTO upload_batches (batch_id, file_count, total_rows, distinct_sessions)
      VALUES (?, ?, ?, ?)
    `).run(batchId, req.files.length, totalRaw, totalInserted);

    // ── STEP 3: Get available filter values from DB ───────────────
    const bvList  = db.prepare(`SELECT DISTINCT build_version FROM sessions WHERE upload_batch=? AND build_version IS NOT NULL ORDER BY build_version`).all(batchId).map(r=>r.build_version);
    const lccList = db.prepare(`SELECT DISTINCT lcc_revision  FROM sessions WHERE upload_batch=? AND lcc_revision  IS NOT NULL ORDER BY lcc_revision`).all(batchId).map(r=>r.lcc_revision);
    const dates   = db.prepare(`SELECT DISTINCT date          FROM sessions WHERE upload_batch=? AND date          IS NOT NULL ORDER BY date`).all(batchId).map(r=>r.date);

    console.log(`\n✅ [Step 2] All data stored in SQLite. BatchId: ${batchId}`);
    console.log(`   Total: ${totalRaw.toLocaleString()} raw rows → ${totalInserted.toLocaleString()} distinct sessions`);
    console.log(`   Dates: ${dates.join(', ')}`);
    console.log(`   Build versions: ${bvList.join(', ')}`);
    console.log(`\n🔍 [Step 3] Frontend will now call /api/kpis/* with batch=${batchId}`);

    // Return batchId → frontend uses it to query KPIs from DB
    res.json({
      batchId,
      totalRawRows     : totalRaw,
      totalInserted,
      duplicatesRemoved: totalRaw - totalInserted,
      files            : fileResults,
      filterOptions    : { buildVersions: bvList, lccRevisions: lccList, dates },
      message          : `Data stored in SQLite. ${totalInserted.toLocaleString()} distinct sessions ready to query.`,
    });

  } catch (err) {
    console.error('❌ Upload error:', err);
    // Rollback: remove partial data
    try { db.prepare('DELETE FROM sessions WHERE upload_batch=?').run(batchId); } catch(_) {}
    res.status(500).json({ error: err.message });
  }
});

// DELETE batch
router.delete('/:batchId', (req, res) => {
  const db = getDb();
  try {
    db.prepare('DELETE FROM sessions       WHERE upload_batch=?').run(req.params.batchId);
    db.prepare('DELETE FROM upload_batches WHERE batch_id=?').run(req.params.batchId);
    res.json({ ok: true, message: 'Batch deleted from SQLite' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
