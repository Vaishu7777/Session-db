const express  = require('express');
const multer   = require('multer');
const { v4: uuid } = require('uuid');
const { Transform, Readable } = require('stream');
const { parse }  = require('csv-parse');
const XLSX       = require('xlsx');
const { getDb }  = require('../db');
const { enrichRows, detectCols } = require('../utils/parser');

const router = express.Router();

// ── Multer: up to 5 files, 500 MB each ───────────────────────────
const upload = multer({
  storage: multer.memoryStorage(),
  limits : { fileSize: 500 * 1024 * 1024, files: 5 },
});

const BATCH_SIZE = 5000; // rows per SQLite transaction (optimal for speed)

// ── Stream-parse CSV → enriched rows → batch INSERT ──────────────
function processCSVStream(buffer, cm, fileName, batchId, insertMany, onProgress) {
  return new Promise((resolve, reject) => {
    let rawCount = 0, insertedCount = 0;
    let batch    = [];
    const seen   = new Set();

    const parser = parse({
      columns          : true,
      skip_empty_lines : true,
      trim             : true,
      relax_quotes     : true,
      relax_column_count: true,
      bom              : true,
    });

    parser.on('readable', () => {
      let record;
      while ((record = parser.read()) !== null) {
        rawCount++;
        const enriched = enrichRows([record], cm, fileName);
        if (!enriched.length) continue;
        const row = enriched[0];

        // DISTINCT dedup
        const sid = row.session_id ? String(row.session_id).trim() : null;
        if (sid && sid !== '' && !['null','nan'].includes(sid.toLowerCase())) {
          if (seen.has(sid)) continue;
          seen.add(sid);
        }

        batch.push({ ...row, upload_batch: batchId });

        // Flush batch to SQLite
        if (batch.length >= BATCH_SIZE) {
          insertMany(batch);
          insertedCount += batch.length;
          if (onProgress) onProgress(rawCount, insertedCount);
          batch = [];
        }
      }
    });

    parser.on('end', () => {
      // Flush remaining
      if (batch.length > 0) {
        insertMany(batch);
        insertedCount += batch.length;
      }
      resolve({ rawCount, insertedCount, distinctCount: seen.size });
    });

    parser.on('error', reject);

    // Feed buffer to parser as stream
    const readable = new Readable();
    readable.push(buffer);
    readable.push(null);
    readable.pipe(parser);
  });
}

// ── Parse Excel synchronously (no streaming available) ────────────
function processExcel(buffer, cm, fileName, batchId, insertMany) {
  const wb  = XLSX.read(buffer, { type: 'buffer', cellDates: false, raw: true });
  const ws  = wb.Sheets[wb.SheetNames[0]];
  const aoa = XLSX.utils.sheet_to_json(ws, { header: 1, defval: null, raw: true });

  if (aoa.length < 2) return { rawCount: 0, insertedCount: 0 };

  const headers = aoa[0].map(h => (h == null ? '' : String(h).trim()));
  const seen    = new Set();
  let rawCount  = 0, insertedCount = 0;
  let batch     = [];

  for (let i = 1; i < aoa.length; i++) {
    const obj = {};
    headers.forEach((h, j) => { if (h) obj[h] = aoa[i][j] ?? null; });

    rawCount++;
    const enriched = enrichRows([obj], cm, fileName);
    if (!enriched.length) continue;
    const row = enriched[0];

    const sid = row.session_id ? String(row.session_id).trim() : null;
    if (sid && sid !== '' && !['null','nan'].includes(sid.toLowerCase())) {
      if (seen.has(sid)) continue;
      seen.add(sid);
    }

    batch.push({ ...row, upload_batch: batchId });

    if (batch.length >= BATCH_SIZE) {
      insertMany(batch);
      insertedCount += batch.length;
      batch = [];
    }
  }

  if (batch.length > 0) {
    insertMany(batch);
    insertedCount += batch.length;
  }

  return { rawCount, insertedCount };
}

// ── POST /api/upload ─────────────────────────────────────────────
router.post('/', upload.array('files', 5), async (req, res) => {
  if (!req.files || req.files.length === 0)
    return res.status(400).json({ error: 'No files uploaded' });

  const db      = getDb();
  const batchId = uuid();
  let totalRaw  = 0, totalInserted = 0;
  const fileResults = [];

  try {
    // Prepare single insert statement
    const insertStmt = db.prepare(`
      INSERT INTO sessions (
        session_id, build_version, lcc_revision, session_start_time,
        hsct, fallback_start_time, fallback_cause, date,
        auth_login_time, mqtt_hsct, plant_flag, file_name, upload_batch
      ) VALUES (
        @session_id, @build_version, @lcc_revision, @session_start_time,
        @hsct, @fallback_start_time, @fallback_cause, @date,
        @auth_login_time, @mqtt_hsct, @plant_flag, @file_name, @upload_batch
      )
    `);

    // Batch transaction wrapper
    const insertMany = db.transaction((rows) => {
      for (const row of rows) insertStmt.run(row);
    });

    for (const file of req.files) {
      const ext     = file.originalname.split('.').pop().toLowerCase();
      const isCSV   = ext === 'csv';
      const sizeMB  = (file.size / 1024 / 1024).toFixed(1);
      console.log(`\n📂 Processing: ${file.originalname} (${sizeMB} MB)`);

      // Detect columns from first chunk for CSV, or from parsed data for Excel
      let cm, stats;

      if (isCSV) {
        // Peek at first 10 rows to detect columns
        const textSample = file.buffer.toString('utf-8', 0, Math.min(8192, file.buffer.length));
        const sampleRows = textSample.split('\n').slice(0, 3);
        const headerLine = sampleRows[0];
        const headers    = headerLine.split(',').map(h => h.trim().replace(/^"|"$/g,''));
        cm = detectCols(headers);

        console.log(`  Columns detected: SessionId=${cm.sessionId}, HSCT=${cm.hsctRaw}, Login=${cm.loginTime}`);

        // Stream process
        stats = await processCSVStream(
          file.buffer, cm, file.originalname, batchId, insertMany,
          (raw, ins) => {
            if (raw % 50000 === 0) console.log(`  Progress: ${raw.toLocaleString()} rows parsed, ${ins.toLocaleString()} inserted`);
          }
        );
      } else {
        // Excel
        const wb  = XLSX.read(file.buffer, { type: 'buffer', cellDates: false, raw: true });
        const ws  = wb.Sheets[wb.SheetNames[0]];
        const aoa = XLSX.utils.sheet_to_json(ws, { header: 1, defval: null, raw: true });
        const hdrs = aoa[0]?.map(h => h == null ? '' : String(h).trim()) || [];
        cm    = detectCols(hdrs);
        stats = processExcel(file.buffer, cm, file.originalname, batchId, insertMany);
      }

      totalRaw      += stats.rawCount;
      totalInserted += stats.insertedCount;

      console.log(`  ✅ Done: ${stats.rawCount.toLocaleString()} raw → ${stats.insertedCount.toLocaleString()} distinct inserted`);

      fileResults.push({
        file             : file.originalname,
        sizeMB,
        status           : 'ok',
        rawRows          : stats.rawCount,
        inserted         : stats.insertedCount,
        duplicatesRemoved: stats.rawCount - stats.insertedCount,
        colMap           : cm,
        detectedCols     : Object.entries(cm).map(([field, col]) => ({
          field, col, found: !!col,
        })),
      });
    }

    // Record batch
    db.prepare(`
      INSERT INTO upload_batches (batch_id, file_count, total_rows, distinct_sessions)
      VALUES (?, ?, ?, ?)
    `).run(batchId, req.files.length, totalRaw, totalInserted);

    // Filter options
    const bvList  = db.prepare(`SELECT DISTINCT build_version  FROM sessions WHERE upload_batch=? AND build_version  IS NOT NULL ORDER BY build_version`).all(batchId).map(r => r.build_version);
    const lccList = db.prepare(`SELECT DISTINCT lcc_revision   FROM sessions WHERE upload_batch=? AND lcc_revision   IS NOT NULL ORDER BY lcc_revision`).all(batchId).map(r => r.lcc_revision);
    const dates   = db.prepare(`SELECT DISTINCT date            FROM sessions WHERE upload_batch=? AND date           IS NOT NULL ORDER BY date`).all(batchId).map(r => r.date);

    res.json({
      batchId,
      totalRawRows     : totalRaw,
      totalInserted,
      duplicatesRemoved: totalRaw - totalInserted,
      files            : fileResults,
      filterOptions    : { buildVersions: bvList, lccRevisions: lccList, dates },
    });

  } catch (err) {
    console.error('Upload error:', err);
    try { db.prepare('DELETE FROM sessions WHERE upload_batch = ?').run(batchId); } catch (_) {}
    res.status(500).json({ error: err.message });
  }
});

// ── DELETE batch ──────────────────────────────────────────────────
router.delete('/:batchId', (req, res) => {
  const db = getDb();
  try {
    db.prepare('DELETE FROM sessions       WHERE upload_batch=?').run(req.params.batchId);
    db.prepare('DELETE FROM upload_batches WHERE batch_id=?').run(req.params.batchId);
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
