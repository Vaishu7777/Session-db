const express  = require('express');
const ExcelJS  = require('exceljs');
const { computeKPIs, getTrend, getFallbackTrend } = require('../utils/compute');

const router = express.Router();

function parseParams(q) {
  return {
    batch        : q.batch || null,
    buildVersions: q.buildVersions ? q.buildVersions.split(',').filter(Boolean) : [],
    lccRevisions : q.lccRevisions  ? q.lccRevisions.split(',').filter(Boolean)  : [],
    fromDate     : q.fromDate  || null,
    toDate       : q.toDate    || null,
    hsctEnd      : parseFloat(q.hsctEnd)  || 5,
    loginThr     : parseFloat(q.loginThr) || 1,
  };
}

const PINK    = 'FFf472b6';
const PURPLE  = 'FFa855f7';
const MINT    = 'FF34d399';
const AMBER   = 'FFfbbf24';
const ROSE    = 'FFf43f5e';
const DARK_BG = 'FF0d0018';
const HEADER_BG = 'FF2a0040';

function styleHeader(cell, bgHex, fgHex = 'FFfaf5ff') {
  cell.font      = { bold: true, color: { argb: fgHex }, size: 10 };
  cell.fill      = { type: 'pattern', pattern: 'solid', fgColor: { argb: bgHex } };
  cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
  cell.border    = { bottom: { style: 'thin', color: { argb: PINK } } };
}

function pctFmt(v) { return v == null ? '—' : Number(v).toFixed(2) + '%'; }

// GET /api/export/excel
router.get('/excel', async (req, res) => {
  try {
    const params   = parseParams(req.query);
    const summary  = computeKPIs(params);
    const trend    = getTrend(params);
    const fallback = getFallbackTrend(params);

    const wb = new ExcelJS.Workbook();
    wb.creator  = 'Session Analytics Dashboard';
    wb.created  = new Date();

    // ── Sheet 1: KPI Summary ──────────────────────────────────────
    const ws1 = wb.addWorksheet('KPI Summary', { properties: { tabColor: { argb: PINK } } });
    ws1.properties.defaultRowHeight = 24;

    ws1.mergeCells('A1:D1');
    const titleCell = ws1.getCell('A1');
    titleCell.value     = 'Session Analytics — KPI Summary';
    titleCell.font      = { bold: true, size: 14, color: { argb: PINK } };
    titleCell.alignment = { horizontal: 'center' };
    titleCell.fill      = { type: 'pattern', pattern: 'solid', fgColor: { argb: DARK_BG } };

    ws1.addRow([]);
    const h2 = ws1.addRow(['KPI', 'Value', 'Formula', 'Description']);
    ['A','B','C','D'].forEach(col => styleHeader(ws1.getCell(`${col}3`), HEADER_BG));

    const kpiRows = [
      ['Total Sessions (DISTINCT)',      summary.totalSessions.toLocaleString(),     'COUNT(DISTINCT SessionId)',                                      'All unique sessions'],
      ['Plant Sessions',                 summary.plantSessions.toLocaleString(),      'COUNT(DISTINCT SessionId WHERE PLANT)',                          'FallbackStartTime is null/nan'],
      ['Non-Plant Sessions',             summary.nonPlantSessions.toLocaleString(),   'COUNT(DISTINCT SessionId WHERE NON-PLANT)',                      'FallbackStartTime present'],
      ['Plant Attachment Rate',          pctFmt(summary.plantAttachRate),             'Plant / Total',                                                  'Metric 1'],
      [`% Total HSCT ≤ ${params.hsctEnd}s`,   pctFmt(summary.hsctRate),              `COUNT(DISTINCT HSCT≤${params.hsctEnd}) / Total`,                'Metric 2'],
      [`% Plant HSCT ≤ ${params.hsctEnd}s`,   pctFmt(summary.plantHsctRate),         `COUNT(DISTINCT Plant & HSCT≤${params.hsctEnd}) / Total Plant`,  'Metric 3'],
      [`% Non-Plant MQTT HSCT ≤ ${params.hsctEnd}s`, pctFmt(summary.nonPlantHsctRate), `COUNT(DISTINCT NP & MQTT≤${params.hsctEnd}) / Total NP`,     'Metric 5'],
      [`% Login ≤ ${params.loginThr}s`,       pctFmt(summary.loginRate),             `COUNT(DISTINCT Login≤${params.loginThr}) / Sessions with Login`,'Metric 4'],
      ['Sessions with HSCT met',         summary.hsctCount.toLocaleString(),          `DISTINCT SessionId where HSCT ≤ ${params.hsctEnd}s`,            'KPI 12'],
      ['Plant HSCT sessions',            summary.plantHsctCount.toLocaleString(),     'KPI 15',                                                         ''],
      ['Non-Plant HSCT sessions',        summary.nonPlantHsctCount.toLocaleString(),  'KPI 16',                                                         ''],
      ['Login sessions (≤ thr)',         summary.loginCount.toLocaleString(),          '',                                                               ''],
    ];

    const colors = [PINK, MINT, AMBER, ROSE, PINK, MINT, AMBER, PURPLE, PINK, MINT, AMBER, PURPLE];
    kpiRows.forEach((row, i) => {
      const r = ws1.addRow(row);
      r.getCell(1).font = { bold: true, color: { argb: DARK_BG === 'FF0d0018' ? 'FFc4b5d4' : 'FF333333' } };
      r.getCell(2).font = { bold: true, color: { argb: colors[i] }, size: 12 };
      r.getCell(2).alignment = { horizontal: 'center' };
      r.getCell(3).font = { color: { argb: 'FF7c6b8a' }, italic: true, size: 9 };
      r.getCell(4).font = { color: { argb: 'FF7c6b8a' }, size: 9 };
      r.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: i % 2 === 0 ? 'FF0d0018' : 'FF130020' } };
    });

    ws1.columns = [{ width: 36 }, { width: 18 }, { width: 42 }, { width: 36 }];

    // ── Sheet 2: Daily Trend ──────────────────────────────────────
    const ws2 = wb.addWorksheet('Daily Trend', { properties: { tabColor: { argb: MINT } } });
    ws2.properties.defaultRowHeight = 22;

    const tHeaders = ['Date', 'Total Sessions', 'Plant Sessions', 'Non-Plant', 'Plant Rate %', `HSCT ≤${params.hsctEnd}s %`, `Plant HSCT %`, `NP HSCT %`, `Login ≤${params.loginThr}s %`];
    const th = ws2.addRow(tHeaders);
    ['A','B','C','D','E','F','G','H','I'].forEach(col => styleHeader(ws2.getCell(`${col}1`), HEADER_BG));

    trend.forEach((row, i) => {
      const r = ws2.addRow([
        row.date, row.total, row.plant, row.nonPlant,
        pctFmt(row.plantRate), pctFmt(row.hsctRate),
        pctFmt(row.plantHsctRate), pctFmt(row.npHsctRate), pctFmt(row.loginRate),
      ]);
      r.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: i % 2 === 0 ? 'FF0d0018' : 'FF130020' } };
      // Colour values
      r.getCell(5).font = { color: { argb: ROSE },   bold: true };
      r.getCell(6).font = { color: { argb: PINK },   bold: true };
      r.getCell(7).font = { color: { argb: MINT },   bold: true };
      r.getCell(8).font = { color: { argb: AMBER },  bold: true };
      r.getCell(9).font = { color: { argb: PURPLE }, bold: true };
    });

    ws2.columns = [
      { width: 14 }, { width: 16 }, { width: 14 }, { width: 12 },
      { width: 14 }, { width: 14 }, { width: 14 }, { width: 14 }, { width: 14 },
    ];

    // Add auto-filter
    ws2.autoFilter = { from: 'A1', to: `I${trend.length + 1}` };

    // ── Sheet 3: Fallback Trend ───────────────────────────────────
    const ws3 = wb.addWorksheet('Fallback Top 5', { properties: { tabColor: { argb: ROSE } } });
    ws3.properties.defaultRowHeight = 22;

    const fh = ws3.addRow(['FallbackCause', 'Total Count']);
    ['A','B'].forEach(col => styleHeader(ws3.getCell(`${col}1`), HEADER_BG));

    const fbColors = [PINK, PURPLE, MINT, AMBER, ROSE];
    fallback.forEach((f, i) => {
      const r = ws3.addRow([f.cause, f.total]);
      r.getCell(1).font = { color: { argb: fbColors[i] }, bold: true };
      r.getCell(2).font = { color: { argb: fbColors[i] }, bold: true };
      r.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: i % 2 === 0 ? 'FF0d0018' : 'FF130020' } };
    });
    ws3.columns = [{ width: 40 }, { width: 16 }];

    // ── Stream to response ────────────────────────────────────────
    const filename = `session-analytics-${new Date().toISOString().slice(0, 10)}.xlsx`;
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    await wb.xlsx.write(res);
    res.end();

  } catch (err) {
    console.error('Export error:', err);
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
