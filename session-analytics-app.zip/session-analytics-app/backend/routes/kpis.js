const express = require('express');
const { computeKPIs, getTrend, getFallbackTrend, getHsctDistribution, getFilterOptions, getBatches } = require('../utils/compute');
const router = express.Router();

function parseParams(q) {
  return {
    batch         : q.batch || null,
    buildVersions : q.buildVersions ? q.buildVersions.split(',').filter(Boolean) : [],
    lccRevisions  : q.lccRevisions  ? q.lccRevisions.split(',').filter(Boolean)  : [],
    fromDate      : q.fromDate  || null,
    toDate        : q.toDate    || null,
    hsctStart     : parseFloat(q.hsctStart) || 0,
    hsctEnd       : parseFloat(q.hsctEnd)   || 5,
    loginThr      : parseFloat(q.loginThr)  || 1,
    lastDays      : parseInt(q.lastDays)    || 0,
  };
}

router.get('/batches',   (_, res) => { try { res.json(getBatches()); }                           catch(e) { res.status(500).json({ error: e.message }); }});
router.get('/filters',   (req, res) => { try { res.json(getFilterOptions(req.query.batch||null)); } catch(e) { res.status(500).json({ error: e.message }); }});
router.get('/summary',   (req, res) => { try { res.json(computeKPIs(parseParams(req.query))); }     catch(e) { res.status(500).json({ error: e.message }); }});
router.get('/trend',     (req, res) => { try { res.json(getTrend(parseParams(req.query))); }         catch(e) { res.status(500).json({ error: e.message }); }});
router.get('/fallback',  (req, res) => { try { res.json(getFallbackTrend(parseParams(req.query)));} catch(e) { res.status(500).json({ error: e.message }); }});
router.get('/hsct-dist', (req, res) => { try { res.json(getHsctDistribution(parseParams(req.query))); } catch(e) { res.status(500).json({ error: e.message }); }});

module.exports = router;
