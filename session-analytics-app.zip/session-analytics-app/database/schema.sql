-- ================================================================
-- Session Analytics Dashboard — Database Schema
-- Optimised for 1M+ rows with covering indexes
-- ================================================================

PRAGMA journal_mode = WAL;
PRAGMA synchronous   = NORMAL;
PRAGMA cache_size    = -131072;   -- 128 MB
PRAGMA temp_store    = MEMORY;
PRAGMA mmap_size     = 536870912; -- 512 MB

-- ── Sessions table ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS sessions (
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id          TEXT    NOT NULL,
  build_version       TEXT,
  lcc_revision        TEXT,
  session_start_time  REAL,
  hsct                REAL,     -- Derived: System_HomeScreen - SessionStart (seconds)
  fallback_start_time TEXT,
  fallback_cause      TEXT,
  date                TEXT,     -- YYYY-MM-DD
  auth_login_time     REAL,     -- seconds
  mqtt_hsct           REAL,     -- MQTT_Time_to_Construct_Home_Screen
  plant_flag          TEXT NOT NULL DEFAULT 'PLANT',  -- 'PLANT' | 'NON-PLANT'
  file_name           TEXT,
  upload_batch        TEXT
);

-- ── Upload batches ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS upload_batches (
  batch_id          TEXT    PRIMARY KEY,
  created_at        TEXT    DEFAULT (datetime('now')),
  file_count        INTEGER DEFAULT 0,
  total_rows        INTEGER DEFAULT 0,
  distinct_sessions INTEGER DEFAULT 0
);

-- ── Indexes: tuned for COUNT(DISTINCT session_id) KPI queries ────

-- Basic lookups
CREATE INDEX IF NOT EXISTS idx_session_id  ON sessions(session_id);
CREATE INDEX IF NOT EXISTS idx_date        ON sessions(date);
CREATE INDEX IF NOT EXISTS idx_batch       ON sessions(upload_batch);
CREATE INDEX IF NOT EXISTS idx_plant       ON sessions(plant_flag);
CREATE INDEX IF NOT EXISTS idx_build       ON sessions(build_version);
CREATE INDEX IF NOT EXISTS idx_lcc         ON sessions(lcc_revision);

-- Covering index for all KPI queries in one index scan
-- Covers: session_id, date, plant_flag, hsct, mqtt_hsct, auth_login_time
CREATE INDEX IF NOT EXISTS idx_kpi_core ON sessions(
  upload_batch, date, plant_flag, session_id, hsct, mqtt_hsct, auth_login_time
);

-- For fallback trend
CREATE INDEX IF NOT EXISTS idx_fallback ON sessions(fallback_cause, date, session_id);
